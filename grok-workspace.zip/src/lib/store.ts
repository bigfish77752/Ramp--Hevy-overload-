import { create } from "zustand";
import { persist } from "zustand/middleware";
import { buildSampleSets } from "@/lib/hevy/sample";
import type { SetRow, Unit } from "@/lib/hevy/types";

export type Source = "sample" | "import" | "empty";

type RampState = {
  hydrated: boolean;
  unit: Unit;
  source: Source;
  sets: SetRow[];
  fileName: string | null;
  importedAt: number | null;
  setHydrated: () => void;
  setUnit: (unit: Unit) => void;
  loadImported: (sets: SetRow[], fileName: string) => void;
  loadSample: () => void;
  clear: () => void;
};

export const useRampStore = create<RampState>()(
  persist(
    (set) => ({
      hydrated: false,
      unit: "kg",
      source: "sample",
      sets: buildSampleSets(),
      fileName: null,
      importedAt: null,
      setHydrated: () => set({ hydrated: true }),
      setUnit: (unit) => set({ unit }),
      loadImported: (sets, fileName) =>
        set({
          sets,
          fileName,
          source: "import",
          importedAt: Date.now(),
        }),
      loadSample: () =>
        set({
          sets: buildSampleSets(),
          source: "sample",
          fileName: null,
          importedAt: null,
        }),
      clear: () =>
        set({
          sets: [],
          source: "empty",
          fileName: null,
          importedAt: null,
        }),
    }),
    {
      name: "ramp-hevy-v1",
      partialize: (s) => ({
        unit: s.unit,
        source: s.source,
        sets: s.sets,
        fileName: s.fileName,
        importedAt: s.importedAt,
      }),
      skipHydration: true,
    },
  ),
);
