import type { Status } from "./types";

export const STATUS_LABEL: Record<Status, string> = {
  pr: "PR",
  progressing: "Up",
  holding: "Hold",
  stalling: "Stall",
  slipping: "Down",
  new: "New",
};
