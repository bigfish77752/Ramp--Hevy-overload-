import assert from "node:assert/strict";
import { test } from "node:test";
import { parseWorkoutCsv, setsToHevyCsv } from "./parse-csv.ts";
import { analyze } from "./overload.ts";
import { buildSampleSets } from "./sample.ts";

test("parses Hevy native CSV with locale timestamps", () => {
  const csv = `title,start_time,end_time,exercise_title,set_index,set_type,weight_kg,reps,rpe
Push,"28 Mar 2025, 17:29","28 Mar 2025, 18:45",Bench Press (Barbell),0,warmup,40,8,
Push,"28 Mar 2025, 17:29","28 Mar 2025, 18:45",Bench Press (Barbell),1,normal,80,8,8
Push,"28 Mar 2025, 17:29","28 Mar 2025, 18:45",Bench Press (Barbell),2,normal,80,8,8
Push,"28 Mar 2025, 17:29","28 Mar 2025, 18:45",Bench Press (Barbell),3,normal,80,7,9`;
  const result = parseWorkoutCsv(csv);
  assert.equal(result.format, "hevy");
  assert.equal(result.sets.length, 4);
  assert.equal(result.sets[1].exercise, "Bench Press (Barbell)");
  assert.equal(result.sets[1].weightKg, 80);
  assert.equal(result.sets[1].reps, 8);
  assert.ok(!Number.isNaN(result.sets[0].start));
});

test("parses weight_lbs and Strong-style headers", () => {
  const csv = `Date,Workout Name,Exercise Name,Set Order,Weight,Reps
2025-01-15 18:00:00,Leg Day,Squat (Barbell),1,225,5
2025-01-15 18:00:00,Leg Day,Squat (Barbell),2,225,5`;
  const result = parseWorkoutCsv(csv);
  assert.equal(result.format, "strong");
  assert.equal(result.sets.length, 2);
  assert.ok(result.sets[0].weightKg && result.sets[0].weightKg > 90);
});

test("sample log round-trips and yields next targets", () => {
  const sets = buildSampleSets();
  assert.ok(sets.length > 200);
  const csv = setsToHevyCsv(sets);
  const parsed = parseWorkoutCsv(csv);
  assert.equal(parsed.sets.length, sets.length);
  const model = analyze(parsed.sets, "kg");
  assert.ok(model.exercises.length >= 10);
  assert.ok(model.due);
  assert.ok(model.due.exercises.length > 0);
  const bench = model.exercises.find((e) => e.name.includes("Bench Press (Barbell)"));
  assert.ok(bench);
  assert.ok(bench.next.sets >= 1);
  assert.ok(["pr", "progressing", "holding", "stalling", "slipping", "new"].includes(bench.status));
});
