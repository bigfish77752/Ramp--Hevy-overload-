import { classifyMuscle } from "./muscles";
import type {
  DashboardModel,
  DueWorkout,
  ExerciseSession,
  ExerciseSummary,
  NextTarget,
  SetRow,
  Status,
  TopSet,
  Unit,
} from "./types";
import { formatIncrement, plateIncrementKg, toSlug } from "./units";

const DAY = 86_400_000;
const WEEK = 7 * DAY;

export function analyze(sets: SetRow[], unit: Unit, now = Date.now()): DashboardModel {
  const working = sets.filter(isWorkingSet);
  const byExercise = new Map<string, SetRow[]>();
  for (const s of working) {
    const list = byExercise.get(s.exercise);
    if (list) list.push(s);
    else byExercise.set(s.exercise, [s]);
  }

  const exercises: ExerciseSummary[] = [];
  const slugUsed = new Set<string>();

  for (const [name, rows] of byExercise) {
    const sessions = groupSessions(rows);
    if (sessions.length === 0) continue;
    const isBodyweight = sessions.every((s) => s.workingWeightKg <= 0);
    const last = sessions[sessions.length - 1];
    const prev = sessions.length > 1 ? sessions[sessions.length - 2] : null;
    const bestE1rm = sessions.reduce((m, s) => Math.max(m, s.e1rm), 0);
    const status = classifyStatus(sessions, now);
    const stallSessions = countStall(sessions);
    const next = prescribe(sessions, unit, stallSessions, isBodyweight);
    let slug = toSlug(name);
    if (slugUsed.has(slug)) slug = `${slug}-${sessions.length}`;
    slugUsed.add(slug);

    const lastMetric = metric(last);
    const prevMetric = prev ? metric(prev) : lastMetric;

    exercises.push({
      name,
      slug,
      muscle: classifyMuscle(name),
      lastDate: last.start,
      sessions: sessions.length,
      lastTopSet: last.topSets[0] ?? null,
      lastRepsList: last.topSets.map((t) => t.reps),
      lastVolume: last.volumeKg,
      bestE1rm,
      lastE1rm: last.e1rm,
      e1rmDelta: prev ? lastMetric - prevMetric : 0,
      volumeDelta: prev ? last.volumeKg - prev.volumeKg : 0,
      status,
      stallSessions,
      next,
      trend: sessions.map((s) => ({
        date: s.start,
        e1rm: s.e1rm,
        volume: s.volumeKg,
        topWeight: s.workingWeightKg,
      })),
      history: sessions,
      isBodyweight,
    });
  }

  exercises.sort((a, b) => statusRank(a.status) - statusRank(b.status) || b.lastDate - a.lastDate);

  const weeklyVolume = weeklyBuckets(working, now);
  const due = pickDue(exercises, working, now);
  const weekAgo = now - 7 * DAY;
  const twoWeeks = now - 14 * DAY;
  const monthAgo = now - 28 * DAY;

  const workoutKeys = new Set<string>();
  for (const s of working) {
    if (s.start >= monthAgo) workoutKeys.add(`${s.start}|${s.workoutTitle}`);
  }

  return {
    exercises,
    weeklyVolume,
    due,
    lastWorkoutTitle: latestTitle(working),
    lastWorkoutDate: working.reduce((m, s) => Math.max(m, s.start), 0) || null,
    stats: {
      sessions28: workoutKeys.size,
      volume7: volumeBetween(working, weekAgo, now),
      volume7prev: volumeBetween(working, twoWeeks, weekAgo),
      prs28: exercises.filter((e) => e.status === "pr" && e.lastDate >= monthAgo).length,
      stalled: exercises.filter((e) => e.status === "stalling").length,
      lifts: exercises.length,
    },
  };
}

function isWorkingSet(s: SetRow): boolean {
  const t = s.setType.toLowerCase().replace(/[\s_-]+/g, "");
  if (t.includes("warm") || t.includes("cool")) return false;
  const hasReps = (s.reps ?? 0) > 0;
  const hasWeight = (s.weightKg ?? 0) > 0;
  const hasTime = (s.durationSec ?? 0) > 0;
  if (hasTime && !hasReps) return false;
  return hasReps || hasWeight;
}

function groupSessions(rows: SetRow[]): ExerciseSession[] {
  const map = new Map<string, SetRow[]>();
  for (const s of rows) {
    const key = `${s.start}|${s.workoutTitle}`;
    const list = map.get(key);
    if (list) list.push(s);
    else map.set(key, [s]);
  }
  const sessions: ExerciseSession[] = [];
  for (const [, group] of map) {
    const session = toSession(group);
    if (session) sessions.push(session);
  }
  sessions.sort((a, b) => a.start - b.start);
  return sessions;
}

function toSession(group: SetRow[]): ExerciseSession | null {
  const usable = group.filter((s) => (s.reps ?? 0) > 0);
  if (usable.length === 0) return null;
  const weights = usable.map((s) => s.weightKg ?? 0);
  const workingWeightKg = Math.max(...weights);
  const band = workingWeightKg > 0 ? workingWeightKg * 0.025 : 0;
  const topRows =
    workingWeightKg > 0
      ? usable.filter((s) => (s.weightKg ?? 0) >= workingWeightKg - band)
      : usable;
  const topSets: TopSet[] = topRows.map((s) => ({
    weightKg: s.weightKg ?? 0,
    reps: s.reps ?? 0,
    rpe: s.rpe,
  }));
  const volumeKg = usable.reduce((sum, s) => sum + (s.weightKg ?? 0) * (s.reps ?? 0), 0);
  const totalReps = usable.reduce((sum, s) => sum + (s.reps ?? 0), 0);
  let e1rm = 0;
  for (const t of topSets) {
    if (t.weightKg > 0 && t.reps > 0) e1rm = Math.max(e1rm, epley(t.weightKg, t.reps));
  }
  const first = group[0];
  return {
    start: first.start,
    workoutTitle: first.workoutTitle,
    topSets,
    workingWeightKg,
    totalReps,
    volumeKg,
    e1rm,
    setCount: topSets.length || usable.length,
  };
}

export function epley(weight: number, reps: number): number {
  if (weight <= 0 || reps <= 0) return 0;
  if (reps === 1) return weight;
  return weight * (1 + reps / 30);
}

function metric(s: ExerciseSession): number {
  return s.e1rm > 0 ? s.e1rm : s.totalReps;
}

function classifyStatus(sessions: ExerciseSession[], now: number): Status {
  if (sessions.length < 2) return "new";
  const last = sessions[sessions.length - 1];
  const prev = sessions[sessions.length - 2];
  const bestBefore = sessions.slice(0, -1).reduce((m, s) => Math.max(m, metric(s)), 0);
  const lastM = metric(last);
  const prevM = metric(prev);

  if (bestBefore > 0 && lastM >= bestBefore * 1.005 && last.start >= now - 28 * DAY) {
    return "pr";
  }
  if (prevM > 0 && lastM > prevM * 1.012) return "progressing";

  const recent = sessions.slice(-3);
  if (recent.length === 3) {
    const ms = recent.map(metric);
    const max = Math.max(...ms);
    const min = Math.min(...ms);
    if (max > 0 && (max - min) / max < 0.02) return "stalling";
  }

  if (prevM > 0 && lastM < prevM * 0.97) return "slipping";
  if (prevM > 0 && lastM > prevM) return "progressing";
  return "holding";
}

function countStall(sessions: ExerciseSession[]): number {
  if (sessions.length < 2) return 0;
  let n = 1;
  const last = metric(sessions[sessions.length - 1]);
  for (let i = sessions.length - 2; i >= 0; i--) {
    const m = metric(sessions[i]);
    const top = Math.max(m, last);
    if (top > 0 && Math.abs(m - last) / top < 0.02) n += 1;
    else break;
  }
  return n >= 3 ? n : 0;
}

function inferCeiling(sessions: ExerciseSession[]): number {
  const reps = sessions.slice(-6).flatMap((s) => s.topSets.map((t) => t.reps));
  if (reps.length === 0) return 8;
  const sorted = [...reps].sort((a, b) => a - b);
  const p80 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.8))];
  return clamp(p80, 5, 15);
}

function prescribe(
  sessions: ExerciseSession[],
  unit: Unit,
  stallSessions: number,
  isBodyweight: boolean,
): NextTarget {
  const last = sessions[sessions.length - 1];
  const ceiling = inferCeiling(sessions);
  const floor = Math.max(1, ceiling - 4);
  const repsList = last.topSets.map((t) => t.reps);
  const minR = repsList.length ? Math.min(...repsList) : 8;
  const sets = last.setCount || 3;
  const inc = plateIncrementKg(unit);

  if (isBodyweight) {
    const nextReps = minR + 1;
    return {
      sets,
      weightKg: 0,
      reps: nextReps,
      repsList: last.topSets.map(() => nextReps),
      kind: "add-reps",
      rationale: `Add 1 rep per set (${minR} → ${nextReps}).`,
    };
  }

  if (stallSessions >= 4) {
    const w = last.workingWeightKg * 0.9;
    return {
      sets,
      weightKg: w,
      reps: floor,
      repsList: Array.from({ length: sets }, () => floor),
      kind: "deload",
      rationale: `Flat for ${stallSessions} sessions — reset ~10% and rebuild.`,
    };
  }

  if (repsList.length > 0 && repsList.every((r) => r >= ceiling)) {
    return {
      sets,
      weightKg: last.workingWeightKg + inc,
      reps: floor,
      repsList: Array.from({ length: sets }, () => floor),
      kind: "add-weight",
      rationale: `Hit ${ceiling}s across the board — add ${formatIncrement(unit)}.`,
    };
  }

  const nextRepsList = last.topSets.map((t) => (t.reps < ceiling ? t.reps + 1 : t.reps));
  const lowest = Math.min(...nextRepsList);
  return {
    sets,
    weightKg: last.workingWeightKg,
    reps: lowest,
    repsList: nextRepsList,
    kind: "add-reps",
    rationale:
      lowest >= ceiling
        ? `One more clean set of ${ceiling} earns the next jump.`
        : `Same load. Add 1 rep to the weakest set.`,
  };
}

function pickDue(exercises: ExerciseSummary[], sets: SetRow[], now: number): DueWorkout | null {
  const cutoff = now - 28 * DAY;
  const lastByTitle = new Map<string, number>();
  for (const s of sets) {
    if (s.start < cutoff) continue;
    const prev = lastByTitle.get(s.workoutTitle) ?? 0;
    if (s.start > prev) lastByTitle.set(s.workoutTitle, s.start);
  }
  if (lastByTitle.size === 0) {
    const all = new Map<string, number>();
    for (const s of sets) {
      const prev = all.get(s.workoutTitle) ?? 0;
      if (s.start > prev) all.set(s.workoutTitle, s.start);
    }
    for (const [k, v] of all) lastByTitle.set(k, v);
  }
  if (lastByTitle.size === 0) return null;

  let title = "";
  let lastDate = Number.POSITIVE_INFINITY;
  for (const [t, d] of lastByTitle) {
    if (d < lastDate) {
      lastDate = d;
      title = t;
    }
  }
  const dueExercises = exercises
    .filter((e) => e.history.some((h) => h.workoutTitle === title))
    .sort((a, b) => {
      const aLast = lastOnTitle(a, title);
      const bLast = lastOnTitle(b, title);
      return bLast - aLast;
    })
    .slice(0, 8);

  return {
    title,
    lastDate,
    daysSince: Math.max(0, Math.floor((now - lastDate) / DAY)),
    exercises: dueExercises,
  };
}

function lastOnTitle(ex: ExerciseSummary, title: string): number {
  for (let i = ex.history.length - 1; i >= 0; i--) {
    if (ex.history[i].workoutTitle === title) return ex.history[i].start;
  }
  return 0;
}

function weeklyBuckets(sets: SetRow[], now: number): { weekStart: number; volume: number; sessions: number }[] {
  const startMonday = startOfMonday(now - 11 * WEEK);
  const buckets: { weekStart: number; volume: number; sessions: number }[] = [];
  const keys = new Map<number, Set<string>>();
  for (let i = 0; i < 12; i++) {
    const weekStart = startMonday + i * WEEK;
    buckets.push({ weekStart, volume: 0, sessions: 0 });
    keys.set(weekStart, new Set());
  }
  for (const s of sets) {
    const w = startOfMonday(s.start);
    const b = buckets.find((x) => x.weekStart === w);
    if (!b) continue;
    b.volume += (s.weightKg ?? 0) * (s.reps ?? 0);
    keys.get(w)?.add(`${s.start}|${s.workoutTitle}`);
  }
  for (const b of buckets) {
    b.sessions = keys.get(b.weekStart)?.size ?? 0;
  }
  return buckets;
}

function startOfMonday(ts: number): number {
  const d = new Date(ts);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

function volumeBetween(sets: SetRow[], from: number, to: number): number {
  let v = 0;
  for (const s of sets) {
    if (s.start >= from && s.start < to) v += (s.weightKg ?? 0) * (s.reps ?? 0);
  }
  return v;
}

function latestTitle(sets: SetRow[]): string | null {
  let t: string | null = null;
  let m = 0;
  for (const s of sets) {
    if (s.start >= m) {
      m = s.start;
      t = s.workoutTitle;
    }
  }
  return t;
}

function statusRank(s: Status): number {
  switch (s) {
    case "pr":
      return 0;
    case "progressing":
      return 1;
    case "slipping":
      return 2;
    case "stalling":
      return 3;
    case "holding":
      return 4;
    default:
      return 5;
  }
}

function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

export function formatRepsList(reps: number[]): string {
  if (reps.length === 0) return "—";
  return reps.join(", ");
}

export function copySessionPlan(due: DueWorkout, formatW: (kg: number) => string): string {
  const lines = [`RAMP — ${due.title}`];
  for (const ex of due.exercises) {
    const n = ex.next;
    if (ex.isBodyweight) {
      lines.push(`${ex.name}: ${n.sets} × ${n.repsList.join("/")}`);
    } else {
      lines.push(`${ex.name}: ${n.sets} × ${formatW(n.weightKg)} × ${n.repsList.join("/")}`);
    }
  }
  return lines.join("\n");
}
