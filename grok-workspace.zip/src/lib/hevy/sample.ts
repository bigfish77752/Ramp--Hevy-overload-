import type { SetRow } from "./types";

function mulberry32(seed: number) {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Lift = {
  name: string;
  days: number[];
  weight: number;
  reps: number[];
  stallFrom?: number;
  bodyweight?: boolean;
};

export function buildSampleSets(now = Date.parse("2026-10-03T12:00:00")): SetRow[] {
  const rand = mulberry32(42);
  const lastMonday = startOfMonday(now - 2 * 86400000);
  const weekCount = 12;
  const firstMonday = lastMonday - (weekCount - 1) * 7 * 86400000;

  const lifts: Lift[] = [
    { name: "Bench Press (Barbell)", days: [1, 6], weight: 72.5, reps: [8, 8, 7] },
    { name: "Incline Bench Press (Dumbbell)", days: [1], weight: 28, reps: [10, 10, 9] },
    { name: "Overhead Press (Barbell)", days: [1, 6], weight: 47.5, reps: [6, 6, 5], stallFrom: 7 },
    { name: "Lateral Raise (Dumbbell)", days: [1, 6], weight: 10, reps: [12, 12, 11], stallFrom: 5 },
    { name: "Triceps Pushdown (Cable)", days: [1], weight: 22.5, reps: [12, 12, 10] },
    { name: "Chest Fly (Dumbbell)", days: [6], weight: 14, reps: [12, 12, 12] },
    { name: "Deadlift (Barbell)", days: [2], weight: 130, reps: [5, 5, 5] },
    { name: "Lat Pulldown (Cable)", days: [2, 6], weight: 55, reps: [10, 10, 9] },
    { name: "Seated Row (Cable)", days: [2], weight: 60, reps: [10, 8, 8] },
    { name: "Face Pull (Cable)", days: [2, 6], weight: 15, reps: [15, 15, 12] },
    { name: "Bicep Curl (Barbell)", days: [2], weight: 30, reps: [10, 10, 8] },
    { name: "Pull Up", days: [6], weight: 0, reps: [8, 7, 6], bodyweight: true },
    { name: "Squat (Barbell)", days: [4], weight: 100, reps: [6, 6, 5] },
    { name: "Romanian Deadlift (Barbell)", days: [4], weight: 90, reps: [8, 8, 8] },
    { name: "Leg Press", days: [4], weight: 160, reps: [10, 10, 10] },
    { name: "Lying Leg Curl (Machine)", days: [4], weight: 40, reps: [12, 10, 10] },
    { name: "Calf Raise (Standing)", days: [4], weight: 80, reps: [12, 12, 12] },
    { name: "Hip Thrust (Barbell)", days: [4], weight: 80, reps: [8, 8, 8] },
  ];

  const titles: Record<number, string> = { 1: "Push", 2: "Pull", 4: "Legs", 6: "Upper" };
  const hours: Record<number, [number, number]> = {
    1: [17, 30],
    2: [18, 0],
    4: [17, 0],
    6: [10, 30],
  };

  const sets: SetRow[] = [];

  for (let w = 0; w < weekCount; w++) {
    const deload = w === 8;
    const skipUpper = w === 5;
    for (const day of [1, 2, 4, 6]) {
      if (skipUpper && day === 6) continue;
      const monday = new Date(firstMonday);
      monday.setDate(monday.getDate() + w * 7);
      const [hh, mm] = hours[day];
      const start = new Date(monday);
      start.setDate(start.getDate() + (day - 1));
      start.setHours(hh, mm, 0, 0);
      if (start.getTime() > now) continue;
      const end = new Date(start.getTime() + 72 * 60 * 1000);
      const title = titles[day];

      for (const lift of lifts) {
        if (!lift.days.includes(day)) continue;
        const stalled = lift.stallFrom != null && w >= lift.stallFrom;
        if (w > 0 && !stalled && !lift.bodyweight && w !== 8 && w !== 9) {
          const minR = Math.min(...lift.reps);
          const ceiling = lift.reps[0] >= 10 ? 12 : lift.reps[0] >= 8 ? 8 : 6;
          if (lift.reps.every((r) => r >= ceiling)) {
            lift.weight += lift.weight >= 80 ? 5 : 2.5;
            lift.reps = lift.reps.map(() => Math.max(5, ceiling - 2));
          } else if (minR < ceiling && rand() > 0.25) {
            const i = lift.reps.indexOf(minR);
            lift.reps[i] = minR + 1;
          }
        }
        if (lift.bodyweight && w > 0 && w % 2 === 0 && w < 11) {
          const i = lift.reps.indexOf(Math.min(...lift.reps));
          lift.reps[i] += 1;
        }
        if (stalled && w > (lift.stallFrom ?? 0) && rand() < 0.4) {
          const i = Math.floor(rand() * lift.reps.length);
          lift.reps[i] = Math.max(4, lift.reps[i] + (rand() > 0.5 ? 1 : -1));
        }
        if (w === 11 && lift.name === "Bench Press (Barbell)") {
          lift.weight = 90;
          lift.reps = [6, 6, 5];
        }
        if (w === 11 && lift.name === "Deadlift (Barbell)") {
          lift.weight = 150;
          lift.reps = [5, 5, 4];
        }
        if (w === 10 && lift.name === "Incline Bench Press (Dumbbell)") {
          lift.reps = [8, 7, 6];
        }

        const workingW = deload && !lift.bodyweight ? round2p5(lift.weight * 0.9) : lift.weight;
        const workingReps = deload ? lift.reps.map((r) => Math.max(5, r - 1)) : lift.reps;

        let idx = 0;
        if (!lift.bodyweight) {
          pushSet(sets, title, start, end, lift.name, idx++, "warmup", round2p5(workingW * 0.5), 8);
          pushSet(sets, title, start, end, lift.name, idx++, "warmup", round2p5(workingW * 0.75), 5);
        }
        for (const r of workingReps) {
          const jitter = stalled && rand() < 0.15 ? -1 : 0;
          pushSet(
            sets,
            title,
            start,
            end,
            lift.name,
            idx++,
            "normal",
            lift.bodyweight ? 0 : workingW,
            Math.max(3, r + jitter),
          );
        }
      }
    }
  }

  return sets;
}

function pushSet(
  sets: SetRow[],
  title: string,
  start: Date,
  end: Date,
  exercise: string,
  setIndex: number,
  setType: string,
  weightKg: number,
  reps: number,
) {
  sets.push({
    workoutTitle: title,
    start: start.getTime(),
    end: end.getTime(),
    exercise,
    setIndex,
    setType,
    weightKg,
    reps,
    durationSec: null,
    distanceM: null,
    rpe: setType === "normal" ? 7.5 : null,
    notes: "",
  });
}

function round2p5(n: number): number {
  return Math.round(n * 2) / 2;
}

function startOfMonday(ts: number): number {
  const d = new Date(ts);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
