import type { ParseResult, SetRow } from "./types";
import { KG_PER_LB } from "./units";

export function parseWorkoutCsv(text: string): ParseResult {
  const rows = parseCsv(text);
  if (rows.length < 2) {
    throw new Error("This file looks empty. Export workouts from Hevy and try again.");
  }

  const header = rows[0].map(normalizeHeader);
  const idx = indexColumns(header);
  if (idx.exercise < 0 || idx.start < 0) {
    throw new Error(
      "Couldn't read this CSV. Export from Hevy via Profile → Settings → Export & Import Data → Export Workouts.",
    );
  }

  const format: ParseResult["format"] = idx.hevyNative ? "hevy" : "strong";
  const warnings: string[] = [];
  const sets: SetRow[] = [];
  let skipped = 0;
  let inferredLbs = false;

  const weightIsLbsColumn = idx.weightLbs >= 0 && idx.weightKg < 0;
  let strongWeightLbs: boolean | null = null;

  if (!idx.hevyNative && idx.weight >= 0) {
    const values: number[] = [];
    for (let r = 1; r < rows.length; r++) {
      const n = num(rows[r][idx.weight]);
      if (n !== null && n > 0) values.push(n);
    }
    const max = values.reduce((a, b) => Math.max(a, b), 0);
    strongWeightLbs = max > 280;
    if (strongWeightLbs) inferredLbs = true;
  }

  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    if (row.every((c) => !c.trim())) continue;
    const exercise = (row[idx.exercise] ?? "").trim();
    const startRaw = (row[idx.start] ?? "").trim();
    if (!exercise || !startRaw) {
      skipped += 1;
      continue;
    }
    const start = parseTime(startRaw);
    if (Number.isNaN(start)) {
      skipped += 1;
      continue;
    }
    let end = idx.end >= 0 ? parseTime(row[idx.end] ?? "") : NaN;
    if (Number.isNaN(end)) end = start;

    let weightKg: number | null = null;
    if (idx.weightKg >= 0) {
      weightKg = num(row[idx.weightKg]);
    } else if (idx.weightLbs >= 0) {
      const lbs = num(row[idx.weightLbs]);
      weightKg = lbs === null ? null : lbs * KG_PER_LB;
    } else if (idx.weight >= 0) {
      const w = num(row[idx.weight]);
      if (w !== null) {
        weightKg = strongWeightLbs ? w * KG_PER_LB : w;
      }
    }

    const setType = (idx.setType >= 0 ? row[idx.setType] : "normal")?.trim() || "normal";

    sets.push({
      workoutTitle: (idx.title >= 0 ? row[idx.title] : "Workout")?.trim() || "Workout",
      start,
      end,
      exercise,
      setIndex: int(idx.setIndex >= 0 ? row[idx.setIndex] : "") ?? r,
      setType,
      weightKg,
      reps: idx.reps >= 0 ? num(row[idx.reps]) : null,
      durationSec: idx.seconds >= 0 ? num(row[idx.seconds]) : null,
      distanceM: parseDistance(row, idx),
      rpe: idx.rpe >= 0 ? num(row[idx.rpe]) : null,
      notes: (idx.notes >= 0 ? row[idx.notes] : "")?.trim() || "",
    });
  }

  if (sets.length === 0) {
    throw new Error("No workout sets found in that file.");
  }
  if (skipped > 0) warnings.push(`Skipped ${skipped} incomplete row${skipped === 1 ? "" : "s"}.`);
  if (weightIsLbsColumn) warnings.push("Read weights from weight_lbs.");
  if (inferredLbs) warnings.push("Treated the Weight column as pounds (values looked like lbs).");

  return { sets, warnings, format };
}

function parseDistance(
  row: string[],
  idx: ReturnType<typeof indexColumns>,
): number | null {
  if (idx.distanceKm >= 0) {
    const n = num(row[idx.distanceKm]);
    return n === null ? null : n * 1000;
  }
  if (idx.distanceMiles >= 0) {
    const n = num(row[idx.distanceMiles]);
    return n === null ? null : n * 1609.344;
  }
  if (idx.distance >= 0) {
    return num(row[idx.distance]);
  }
  return null;
}

type ColIdx = {
  hevyNative: boolean;
  title: number;
  start: number;
  end: number;
  exercise: number;
  setIndex: number;
  setType: number;
  weightKg: number;
  weightLbs: number;
  weight: number;
  reps: number;
  seconds: number;
  rpe: number;
  notes: number;
  distanceKm: number;
  distanceMiles: number;
  distance: number;
};

function indexColumns(header: string[]): ColIdx {
  const find = (...names: string[]) => header.findIndex((h) => names.includes(h));
  const exercise = find("exercise_title", "exercise_name", "exercise");
  const start = find("start_time", "date", "workout_datetime", "start");
  return {
    hevyNative: header.includes("exercise_title") || header.includes("start_time"),
    title: find("title", "workout_name", "workout"),
    start,
    end: find("end_time", "end"),
    exercise,
    setIndex: find("set_index", "set_order", "set"),
    setType: find("set_type"),
    weightKg: find("weight_kg"),
    weightLbs: find("weight_lbs"),
    weight: find("weight"),
    reps: find("reps", "repetitions"),
    seconds: find("duration_seconds", "seconds"),
    rpe: find("rpe"),
    notes: find("exercise_notes", "notes"),
    distanceKm: find("distance_km"),
    distanceMiles: find("distance_miles"),
    distance: find("distance"),
  };
}

function normalizeHeader(h: string): string {
  return h
    .replace(/^\uFEFF/, "")
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
}

function num(raw: string | undefined): number | null {
  if (raw == null) return null;
  const t = raw.trim();
  if (!t) return null;
  const n = Number(t.replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function int(raw: string | undefined): number | null {
  const n = num(raw);
  return n === null ? null : Math.round(n);
}

const MONTHS: Record<string, number> = {
  jan: 0,
  feb: 1,
  mar: 2,
  apr: 3,
  may: 4,
  jun: 5,
  jul: 6,
  aug: 7,
  sep: 8,
  oct: 9,
  nov: 10,
  dec: 11,
};

export function parseTime(raw: string): number {
  const t = raw.trim();
  if (!t) return NaN;

  const iso = Date.parse(t);
  if (!Number.isNaN(iso)) return iso;

  const m = t.match(
    /^(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})(?:[,T ]\s*(\d{1,2}):(\d{2})(?::(\d{2}))?)?/,
  );
  if (m) {
    const month = MONTHS[m[2].slice(0, 3).toLowerCase()];
    if (month !== undefined) {
      return new Date(
        Number(m[3]),
        month,
        Number(m[1]),
        Number(m[4] ?? 12),
        Number(m[5] ?? 0),
        Number(m[6] ?? 0),
      ).getTime();
    }
  }

  const sql = t.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (sql) {
    return new Date(
      Number(sql[1]),
      Number(sql[2]) - 1,
      Number(sql[3]),
      Number(sql[4]),
      Number(sql[5]),
      Number(sql[6] ?? 0),
    ).getTime();
  }

  return NaN;
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let i = 0;
  let inQuotes = false;
  const s = text.replace(/^\uFEFF/, "");
  while (i < s.length) {
    const c = s[i];
    if (inQuotes) {
      if (c === '"') {
        if (s[i + 1] === '"') {
          cur += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i += 1;
        continue;
      }
      cur += c;
      i += 1;
      continue;
    }
    if (c === '"') {
      inQuotes = true;
      i += 1;
      continue;
    }
    if (c === ",") {
      row.push(cur);
      cur = "";
      i += 1;
      continue;
    }
    if (c === "\n" || c === "\r") {
      if (c === "\r" && s[i + 1] === "\n") i += 1;
      row.push(cur);
      cur = "";
      if (row.some((x) => x.length > 0) || rows.length > 0) rows.push(row);
      row = [];
      i += 1;
      continue;
    }
    cur += c;
    i += 1;
  }
  row.push(cur);
  if (row.some((x) => x.length > 0)) rows.push(row);
  return rows;
}

export function setsToHevyCsv(sets: SetRow[]): string {
  const header = [
    "title",
    "start_time",
    "end_time",
    "exercise_title",
    "set_index",
    "set_type",
    "weight_kg",
    "reps",
    "duration_seconds",
    "rpe",
    "exercise_notes",
  ];
  const lines = [header.join(",")];
  for (const s of sets) {
    lines.push(
      [
        csvField(s.workoutTitle),
        csvField(new Date(s.start).toISOString()),
        csvField(new Date(s.end).toISOString()),
        csvField(s.exercise),
        String(s.setIndex),
        csvField(s.setType),
        s.weightKg == null ? "" : String(round3(s.weightKg)),
        s.reps == null ? "" : String(s.reps),
        s.durationSec == null ? "" : String(s.durationSec),
        s.rpe == null ? "" : String(s.rpe),
        csvField(s.notes),
      ].join(","),
    );
  }
  return lines.join("\n");
}

function csvField(v: string): string {
  if (/[",\n\r]/.test(v)) return `"${v.replace(/"/g, '""')}"`;
  return v;
}

function round3(n: number): number {
  return Math.round(n * 1000) / 1000;
}
