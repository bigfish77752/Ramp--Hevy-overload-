const RULES: { muscle: string; tests: RegExp[] }[] = [
  {
    muscle: "Chest",
    tests: [/bench/, /chest/, /\bfly\b/, /pec/, /push[-\s]?up/, /pullover/],
  },
  {
    muscle: "Back",
    tests: [
      /deadlift(?!.*romanian)/,
      /\brow\b/,
      /pulldown/,
      /pull[-\s]?up/,
      /chin[-\s]?up/,
      /lat\b/,
      /shrug/,
      /face\s*pull/,
      /rear\s*delt/,
    ],
  },
  {
    muscle: "Shoulders",
    tests: [/overhead press/, /shoulder/, /lateral raise/, /front raise/, /\bohp\b/, /arnold/],
  },
  {
    muscle: "Legs",
    tests: [
      /squat/,
      /lunge/,
      /leg press/,
      /leg curl/,
      /leg extension/,
      /rdl/,
      /romanian/,
      /hip thrust/,
      /glute/,
      /calf/,
      /hack/,
      /split squat/,
      /step[- ]?up/,
    ],
  },
  {
    muscle: "Arms",
    tests: [/curl/, /tricep/, /pushdown/, /skull/, /extension \(cable\)/, /\bdip\b/, /hammer/],
  },
  {
    muscle: "Core",
    tests: [/plank/, /crunch/, /sit-?up/, /pallof/, /ab\b/, /hanging leg/, /cable wood/],
  },
];

export function classifyMuscle(name: string): string {
  const n = name.toLowerCase();
  for (const rule of RULES) {
    if (rule.tests.some((re) => re.test(n))) return rule.muscle;
  }
  return "Other";
}

export const MUSCLE_ORDER = ["Chest", "Back", "Shoulders", "Legs", "Arms", "Core", "Other"];
