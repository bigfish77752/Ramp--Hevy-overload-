import type { Unit } from "./types";

export const KG_PER_LB = 0.45359237;

export function kgToDisplay(kg: number, unit: Unit): number {
  if (unit === "lb") return kg / KG_PER_LB;
  return kg;
}

export function displayToKg(value: number, unit: Unit): number {
  if (unit === "lb") return value * KG_PER_LB;
  return value;
}

export function plateIncrementKg(unit: Unit): number {
  return unit === "lb" ? 5 * KG_PER_LB : 2.5;
}

export function niceWeight(kg: number, unit: Unit): number {
  const raw = kgToDisplay(kg, unit);
  const step = unit === "lb" ? 0.5 : 0.25;
  return Math.round(raw / step) * step;
}

export function formatWeight(kg: number, unit: Unit, digits?: number): string {
  const v = niceWeight(kg, unit);
  const d = digits ?? (unit === "lb" ? (v % 1 === 0 ? 0 : 1) : v % 1 === 0 ? 0 : 2);
  const n = Number.isInteger(v) ? v.toFixed(0) : v.toFixed(Math.min(d, 2));
  return `${trimNum(n)} ${unit}`;
}

export function formatWeightShort(kg: number, unit: Unit): string {
  const v = niceWeight(kg, unit);
  const n = Number.isInteger(v) ? String(v) : v.toFixed(v % 1 === 0 ? 0 : 1);
  return trimNum(n);
}

export function formatIncrement(unit: Unit): string {
  return unit === "lb" ? "5 lb" : "2.5 kg";
}

function trimNum(n: string): string {
  if (!n.includes(".")) return n;
  return n.replace(/\.?0+$/, "");
}

export function toSlug(name: string): string {
  const slug = name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug || "exercise";
}
