export type Unit = "kg" | "lb";

export type SetRow = {
  workoutTitle: string;
  start: number;
  end: number;
  exercise: string;
  setIndex: number;
  setType: string;
  weightKg: number | null;
  reps: number | null;
  durationSec: number | null;
  distanceM: number | null;
  rpe: number | null;
  notes: string;
};

export type Status = "pr" | "progressing" | "holding" | "stalling" | "slipping" | "new";

export type NextKind = "add-weight" | "add-reps" | "repeat" | "deload";

export type TopSet = {
  weightKg: number;
  reps: number;
  rpe: number | null;
};

export type ExerciseSession = {
  start: number;
  workoutTitle: string;
  topSets: TopSet[];
  workingWeightKg: number;
  totalReps: number;
  volumeKg: number;
  e1rm: number;
  setCount: number;
};

export type NextTarget = {
  sets: number;
  weightKg: number;
  reps: number;
  repsList: number[];
  kind: NextKind;
  rationale: string;
};

export type ExerciseSummary = {
  name: string;
  slug: string;
  muscle: string;
  lastDate: number;
  sessions: number;
  lastTopSet: TopSet | null;
  lastRepsList: number[];
  lastVolume: number;
  bestE1rm: number;
  lastE1rm: number;
  e1rmDelta: number;
  volumeDelta: number;
  status: Status;
  stallSessions: number;
  next: NextTarget;
  trend: { date: number; e1rm: number; volume: number; topWeight: number }[];
  history: ExerciseSession[];
  isBodyweight: boolean;
};

export type DueWorkout = {
  title: string;
  lastDate: number;
  daysSince: number;
  exercises: ExerciseSummary[];
};

export type WeeklyBucket = {
  weekStart: number;
  volume: number;
  sessions: number;
};

export type DashboardModel = {
  exercises: ExerciseSummary[];
  weeklyVolume: WeeklyBucket[];
  due: DueWorkout | null;
  lastWorkoutTitle: string | null;
  lastWorkoutDate: number | null;
  stats: {
    sessions28: number;
    volume7: number;
    volume7prev: number;
    prs28: number;
    stalled: number;
    lifts: number;
  };
};

export type ParseResult = {
  sets: SetRow[];
  warnings: string[];
  format: "hevy" | "strong";
};
