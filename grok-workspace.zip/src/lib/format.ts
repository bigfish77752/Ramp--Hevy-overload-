import { formatDistanceToNowStrict, format } from "date-fns";
import type { Unit } from "@/lib/hevy/types";
import { formatWeight, formatWeightShort } from "@/lib/hevy/units";

export function formatDay(ts: number): string {
  return format(ts, "d MMM");
}

export function formatDayFull(ts: number): string {
  return format(ts, "EEE d MMM");
}

export function formatAgo(ts: number, now = Date.now()): string {
  if (now - ts < 20 * 60 * 60 * 1000) return "today";
  if (now - ts < 36 * 60 * 60 * 1000) return "yesterday";
  return formatDistanceToNowStrict(ts, { addSuffix: true });
}

export function formatSetLine(
  sets: number,
  weightKg: number,
  reps: number[],
  unit: Unit,
  bodyweight: boolean,
): string {
  const repsBit = reps.length ? reps.join(", ") : "—";
  if (bodyweight || weightKg <= 0) return `${sets} × ${repsBit}`;
  return `${sets} × ${formatWeight(weightKg, unit)} × ${repsBit}`;
}

export function formatVolume(kg: number, unit: Unit): string {
  const v = unit === "lb" ? kg / 0.45359237 : kg;
  if (v >= 10000) return `${(v / 1000).toFixed(1)}k ${unit}`;
  if (v >= 1000) return `${Math.round(v).toLocaleString()} ${unit}`;
  return `${Math.round(v)} ${unit}`;
}

export function pctDelta(curr: number, prev: number): number | null {
  if (!prev) return null;
  return ((curr - prev) / prev) * 100;
}

export { formatWeight, formatWeightShort };
