import { Link } from "@tanstack/react-router";
import { useRampStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ImportDialog } from "@/components/import-dialog";
import { cn } from "@/lib/cn";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn("size-6", className)}
      fill="none"
      aria-hidden="true"
    >
      <path d="M3 19h4V14H3v5Zm7 0h4V9h-4v10Zm7 0h4V4h-4v15Z" fill="currentColor" />
    </svg>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const unit = useRampStore((s) => s.unit);
  const setUnit = useRampStore((s) => s.setUnit);
  const source = useRampStore((s) => s.source);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between gap-3 px-4">
          <Link to="/" className="flex items-center gap-2 text-fg">
            <Mark className="size-5 text-accent" />
            <span className="font-display text-lg tracking-[0.08em]">RAMP</span>
            {source === "sample" ? (
              <Badge tone="sample" className="hidden sm:inline-flex">
                Sample
              </Badge>
            ) : null}
          </Link>
          <div className="flex items-center gap-2">
            <div className="flex h-11 rounded-md bg-surface-2 p-1 shadow-[var(--shadow-border)]">
              {(["kg", "lb"] as const).map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setUnit(u)}
                  className={cn(
                    "min-w-11 rounded-sm px-3 text-sm font-medium transition-colors duration-150",
                    unit === u ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
                  )}
                >
                  {u}
                </button>
              ))}
            </div>
            <ImportDialog>
              <Button variant="secondary" size="md">
                Import
              </Button>
            </ImportDialog>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 pt-8 pb-[max(2rem,env(safe-area-inset-bottom))]">
        {children}
      </main>
    </div>
  );
}
