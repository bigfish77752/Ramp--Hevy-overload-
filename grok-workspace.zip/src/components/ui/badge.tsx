import { cn } from "@/lib/cn";
import type { HTMLAttributes } from "react";

const tones = {
  pr: "bg-up/15 text-up",
  progressing: "bg-up/15 text-up",
  holding: "bg-fg/8 text-muted",
  stalling: "bg-hold/15 text-hold",
  slipping: "bg-down/15 text-down",
  new: "bg-fg/8 text-muted",
  sample: "bg-accent/15 text-accent",
  muted: "bg-fg/8 text-muted",
} as const;

export function Badge({
  className,
  tone = "muted",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: keyof typeof tones }) {
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center rounded-full px-2.5 text-xs font-medium tracking-wide",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
