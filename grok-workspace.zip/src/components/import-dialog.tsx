import { useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Upload } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { parseWorkoutCsv } from "@/lib/hevy/parse-csv";
import { useRampStore } from "@/lib/store";
import { cn } from "@/lib/cn";

export function ImportDialog({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const [paste, setPaste] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const loadImported = useRampStore((s) => s.loadImported);
  const loadSample = useRampStore((s) => s.loadSample);
  const clear = useRampStore((s) => s.clear);
  const source = useRampStore((s) => s.source);

  function ingest(text: string, name: string) {
    setError(null);
    try {
      const result = parseWorkoutCsv(text);
      loadImported(result.sets, name);
      const workouts = new Set(result.sets.map((s) => `${s.start}|${s.workoutTitle}`)).size;
      toast.success(`Imported ${workouts} workouts · ${result.sets.length} sets`);
      if (result.warnings[0]) toast.message(result.warnings[0]);
      setOpen(false);
      setPaste("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read that file.");
    }
  }

  async function onFile(file: File) {
    const text = await file.text();
    ingest(text, file.name);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogTitle>Import Hevy export</DialogTitle>
        <DialogDescription>
          In Hevy: Profile → Settings → Export & Import Data → Export Workouts. Drop the CSV here —
          nothing leaves this device.
        </DialogDescription>

        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDrag(false);
            const file = e.dataTransfer.files[0];
            if (file) void onFile(file);
          }}
          className={cn(
            "mt-5 flex min-h-32 w-full flex-col items-center justify-center gap-2 rounded-lg bg-surface-2 px-4 text-center shadow-[var(--shadow-border)] transition-[box-shadow] duration-150",
            drag && "shadow-[var(--shadow-border-hover)]",
          )}
        >
          <Upload className="size-5 text-muted" />
          <span className="text-sm text-fg">Drop CSV or click to choose</span>
          <span className="text-xs text-subtle">One row per set · Hevy or Strong format</span>
        </button>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void onFile(file);
            e.currentTarget.value = "";
          }}
        />

        <label className="mt-4 block text-xs font-medium tracking-wide text-muted uppercase">
          Or paste CSV
          <textarea
            value={paste}
            onChange={(e) => setPaste(e.target.value)}
            rows={4}
            className="mt-2 w-full resize-y rounded-md bg-surface-2 p-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none"
            placeholder="title,start_time,exercise_title,..."
          />
        </label>

        {error ? <p className="mt-3 text-sm text-down">{error}</p> : null}

        <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-end">
          {source !== "empty" ? (
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                clear();
                setOpen(false);
                toast.message("Log cleared");
              }}
            >
              Clear log
            </Button>
          ) : null}
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              loadSample();
              setOpen(false);
              toast.success("Loaded a 12-week sample log");
            }}
          >
            Load sample
          </Button>
          <Button
            type="button"
            disabled={!paste.trim()}
            onClick={() => ingest(paste, "pasted.csv")}
          >
            Import paste
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
