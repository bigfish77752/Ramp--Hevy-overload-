import { useEffect, useState, type ReactNode } from "react";
import { useRampStore } from "@/lib/store";

export function Hydrate({
  children,
  fallback = "Loading your training log…",
}: {
  children: ReactNode;
  fallback?: string;
}) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const finish = () => {
      if (cancelled) return;
      useRampStore.getState().setHydrated();
      setReady(true);
    };
    if (useRampStore.persist.hasHydrated()) {
      finish();
      return;
    }
    void Promise.resolve(useRampStore.persist.rehydrate()).then(finish);
    return () => {
      cancelled = true;
    };
  }, []);

  if (!ready) {
    return (
      <div>
        <p className="font-display text-4xl tracking-tight">RAMP</p>
        <p className="mt-2 text-muted">{fallback}</p>
      </div>
    );
  }

  return children;
}
