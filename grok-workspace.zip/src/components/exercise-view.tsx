import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { analyze } from "@/lib/hevy/overload";
import { formatWeight } from "@/lib/hevy/units";
import { useRampStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { STATUS_LABEL } from "@/lib/hevy/status";
import { formatAgo, formatDay, formatSetLine, formatVolume } from "@/lib/format";

export function ExerciseView({ slug }: { slug: string }) {
  const sets = useRampStore((s) => s.sets);
  const unit = useRampStore((s) => s.unit);
  const model = analyze(sets, unit);
  const ex = model.exercises.find((e) => e.slug === slug);

  if (!ex) {
    return (
      <div className="py-16 text-center">
        <p className="font-display text-3xl">Lift not in this log</p>
        <Link to="/" className="mt-4 inline-flex h-11 items-center text-sm text-accent">
          Back to board
        </Link>
      </div>
    );
  }

  const e1rmData = ex.trend.map((t) => ({
    label: formatDay(t.date),
    e1rm: unit === "lb" ? t.e1rm / 0.45359237 : t.e1rm,
    volume: unit === "lb" ? t.volume / 0.45359237 : t.volume,
  }));

  const last = ex.history[ex.history.length - 1];

  return (
    <div className="flex flex-col gap-6">
      <Link
        to="/"
        className="inline-flex h-11 w-fit items-center gap-2 text-sm text-muted transition-colors duration-150 hover:text-fg"
      >
        <ArrowLeft className="size-4" />
        Board
      </Link>

      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">{ex.muscle}</p>
          <h1 className="mt-1 font-display text-4xl tracking-tight sm:text-5xl">{ex.name}</h1>
          <p className="mt-2 text-sm text-muted">
            {ex.sessions} sessions · last {formatAgo(ex.lastDate)}
          </p>
        </div>
        <Badge tone={ex.status} className="h-8 px-3 text-sm">
          {STATUS_LABEL[ex.status]}
        </Badge>
      </header>

      <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
        <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">Next target</p>
        <p className="mt-2 font-display text-3xl tracking-tight sm:text-4xl">
          {formatSetLine(ex.next.sets, ex.next.weightKg, ex.next.repsList, unit, ex.isBodyweight)}
        </p>
        <p className="mt-2 text-sm text-muted">{ex.next.rationale}</p>
        {last ? (
          <p className="mt-4 text-sm text-subtle">
            Last time{" "}
            {formatSetLine(
              last.setCount,
              last.workingWeightKg,
              last.topSets.map((t) => t.reps),
              unit,
              ex.isBodyweight,
            )}
          </p>
        ) : null}
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard
          title={ex.isBodyweight ? "Session reps" : "Estimated 1RM"}
          data={e1rmData}
          dataKey={ex.isBodyweight ? "volume" : "e1rm"}
          unit={unit}
          hideUnit={ex.isBodyweight}
        />
        <ChartCard title="Session volume" data={e1rmData} dataKey="volume" unit={unit} />
      </div>

      <section className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
        <div className="flex items-baseline justify-between px-4 py-4">
          <h2 className="font-display text-2xl tracking-tight">History</h2>
          <p className="text-xs text-muted">Working top sets</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[28rem] text-left text-sm">
            <thead className="text-xs tracking-wide text-muted uppercase">
              <tr className="border-t border-border">
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Session</th>
                <th className="px-4 py-3 font-medium">Top sets</th>
                <th className="px-4 py-3 font-medium">Volume</th>
              </tr>
            </thead>
            <tbody>
              {[...ex.history].reverse().map((h) => (
                <tr key={`${h.start}-${h.workoutTitle}`} className="border-t border-border">
                  <td className="px-4 py-3 tabular whitespace-nowrap">{formatDay(h.start)}</td>
                  <td className="px-4 py-3 text-muted">{h.workoutTitle}</td>
                  <td className="px-4 py-3 tabular">
                    {formatSetLine(
                      h.setCount,
                      h.workingWeightKg,
                      h.topSets.map((t) => t.reps),
                      unit,
                      ex.isBodyweight,
                    )}
                  </td>
                  <td className="px-4 py-3 tabular text-muted">
                    {ex.isBodyweight ? `${h.totalReps} reps` : formatVolume(h.volumeKg, unit)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function ChartCard({
  title,
  data,
  dataKey,
  unit,
  hideUnit,
}: {
  title: string;
  data: { label: string; e1rm: number; volume: number }[];
  dataKey: "e1rm" | "volume";
  unit: "kg" | "lb";
  hideUnit?: boolean;
}) {
  return (
    <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <h2 className="font-display text-2xl tracking-tight">{title}</h2>
      <div className="mt-3 h-44">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="var(--color-border)" vertical={false} />
            <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 11 }} axisLine={false} tickLine={false} minTickGap={24} />
            <YAxis hide domain={["auto", "auto"]} />
            <ReTooltip
              contentStyle={{
                background: "var(--color-surface)",
                border: "1px solid var(--color-border)",
                borderRadius: 8,
                color: "var(--color-fg)",
              }}
              formatter={(value) => [
                hideUnit
                  ? `${Math.round(Number(value))}`
                  : `${Number(value).toFixed(1)} ${unit}`,
                title,
              ]}
            />
            <Area
              type="monotone"
              dataKey={dataKey}
              stroke="var(--color-accent)"
              fill="var(--color-accent)"
              fillOpacity={0.08}
              strokeWidth={1.5}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
