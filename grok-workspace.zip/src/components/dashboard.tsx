import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Copy, Search } from "lucide-react";
import { toast } from "sonner";
import { analyze, copySessionPlan, formatRepsList } from "@/lib/hevy/overload";
import type { ExerciseSummary, Status } from "@/lib/hevy/types";
import { STATUS_LABEL } from "@/lib/hevy/status";
import { useRampStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ImportDialog } from "@/components/import-dialog";
import {
  formatAgo,
  formatDay,
  formatSetLine,
  formatVolume,
  pctDelta,
} from "@/lib/format";
import { formatWeight } from "@/lib/hevy/units";
import { cn } from "@/lib/cn";

export function Dashboard() {
  const sets = useRampStore((s) => s.sets);
  const unit = useRampStore((s) => s.unit);
  const source = useRampStore((s) => s.source);
  const model = useMemo(() => analyze(sets, unit), [sets, unit]);

  if (sets.length === 0 || source === "empty") {
    return <EmptyState />;
  }

  return (
    <div className="flex flex-col gap-8">
      {source === "sample" ? (
        <p className="text-sm text-muted">
          Showing a 12-week sample log. Import your Hevy CSV to replace it — analysis stays on this
          device.
        </p>
      ) : null}

      {model.due ? <DueCard due={model.due} unit={unit} /> : null}

      <StatsRow model={model} unit={unit} />
      <VolumeChart model={model} unit={unit} />
      <OverloadBoard exercises={model.exercises} unit={unit} />
    </div>
  );
}

function EmptyState() {
  const loadSample = useRampStore((s) => s.loadSample);
  return (
    <div className="mx-auto max-w-lg py-12 text-center">
      <p className="font-display text-4xl tracking-tight">Bring a Hevy log.</p>
      <p className="mt-3 text-muted">
        Export workouts from Hevy, drop the CSV here, and RAMP will mark what is moving, what is
        stuck, and what to run next session.
      </p>
      <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
        <ImportDialog>
          <Button size="lg">Import CSV</Button>
        </ImportDialog>
        <Button
          size="lg"
          variant="secondary"
          onClick={() => {
            loadSample();
            toast.success("Loaded a 12-week sample log");
          }}
        >
          Load sample log
        </Button>
      </div>
      <ol className="mt-10 space-y-2 text-left text-sm text-muted">
        <li>1. Open Hevy → Profile → Settings</li>
        <li>2. Export & Import Data → Export Workouts</li>
        <li>3. Drop the CSV onto RAMP</li>
      </ol>
    </div>
  );
}

function DueCard({
  due,
  unit,
}: {
  due: NonNullable<ReturnType<typeof analyze>["due"]>;
  unit: "kg" | "lb";
}) {
  const dueLabel =
    due.daysSince === 0 ? "Due today" : due.daysSince === 1 ? "Due yesterday" : `Due · ${due.daysSince}d`;

  function copy() {
    const text = copySessionPlan(due, (kg) => formatWeight(kg, unit));
    void navigator.clipboard.writeText(text).then(
      () => toast.success("Copied next-session targets"),
      () => toast.error("Could not copy"),
    );
  }

  return (
    <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-[0.16em] text-muted uppercase">Next session</p>
          <h2 className="mt-1 font-display text-4xl tracking-tight sm:text-5xl">{due.title}</h2>
          <p className="mt-1 text-sm text-muted">
            {dueLabel}
            <span className="text-subtle"> · last {formatDay(due.lastDate)}</span>
          </p>
        </div>
        <Button variant="secondary" onClick={copy} className="shrink-0">
          <Copy className="size-4" />
          Copy targets
        </Button>
      </div>

      <ul className="mt-6 divide-y divide-border">
        {due.exercises.map((ex) => (
          <li key={ex.name}>
            <Link
              to="/lift/$slug"
              params={{ slug: ex.slug }}
              className="flex flex-col gap-1 py-4 transition-opacity duration-150 hover:opacity-80 sm:flex-row sm:items-baseline sm:justify-between sm:gap-6"
            >
              <div className="min-w-0">
                <p className="truncate font-medium">{ex.name}</p>
                <p className="text-sm text-muted">
                  Last{" "}
                  {formatSetLine(
                    ex.next.sets,
                    ex.lastTopSet?.weightKg ?? 0,
                    ex.lastRepsList,
                    unit,
                    ex.isBodyweight,
                  )}
                </p>
              </div>
              <div className="sm:text-right">
                <p className="font-medium text-accent">
                  {formatSetLine(
                    ex.next.sets,
                    ex.next.weightKg,
                    ex.next.repsList,
                    unit,
                    ex.isBodyweight,
                  )}
                </p>
                <p className="text-xs text-subtle">{ex.next.rationale}</p>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

function StatsRow({
  model,
  unit,
}: {
  model: ReturnType<typeof analyze>;
  unit: "kg" | "lb";
}) {
  const volDelta = pctDelta(model.stats.volume7, model.stats.volume7prev);
  const tiles = [
    {
      label: "This week",
      value: formatVolume(model.stats.volume7, unit),
      hint:
        volDelta == null
          ? "volume"
          : `${volDelta >= 0 ? "+" : ""}${volDelta.toFixed(0)}% vs last week`,
    },
    {
      label: "28 days",
      value: String(model.stats.sessions28),
      hint: "sessions",
    },
    {
      label: "PRs",
      value: String(model.stats.prs28),
      hint: "this month",
    },
    {
      label: "Stalled",
      value: String(model.stats.stalled),
      hint: "lifts to watch",
    },
  ];

  return (
    <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {tiles.map((t) => (
        <article key={t.label} className="rounded-lg bg-surface px-4 py-4 shadow-[var(--shadow-border)]">
          <p className="text-xs font-medium tracking-[0.14em] text-muted uppercase">{t.label}</p>
          <p className="mt-2 font-display text-3xl tracking-tight tabular">{t.value}</p>
          <p className="mt-1 text-xs text-subtle">{t.hint}</p>
        </article>
      ))}
    </section>
  );
}

function VolumeChart({
  model,
  unit,
}: {
  model: ReturnType<typeof analyze>;
  unit: "kg" | "lb";
}) {
  const data = model.weeklyVolume.map((w) => ({
    label: formatDay(w.weekStart),
    volume: unit === "lb" ? w.volume / 0.45359237 : w.volume,
    sessions: w.sessions,
  }));

  return (
    <section className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-2xl tracking-tight">Weekly volume</h2>
        <p className="text-xs text-muted">Working sets only</p>
      </div>
      <div className="mt-4 h-48">
        <ResponsiveContainer width="100%" height="100%" minWidth={0}>
          <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <XAxis
              dataKey="label"
              tick={{ fill: "var(--color-muted)", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              minTickGap={28}
            />
            <YAxis hide />
            <ReTooltip
              contentStyle={{
                background: "var(--color-surface)",
                border: "1px solid var(--color-border)",
                borderRadius: 8,
                color: "var(--color-fg)",
              }}
              formatter={(value) => [
                `${Math.round(Number(value)).toLocaleString()} ${unit}`,
                "Volume",
              ]}
            />
            <Area
              type="monotone"
              dataKey="volume"
              stroke="var(--color-accent)"
              fill="var(--color-accent)"
              fillOpacity={0.08}
              strokeWidth={1.5}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}

function OverloadBoard({ exercises, unit }: { exercises: ExerciseSummary[]; unit: "kg" | "lb" }) {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | Status>("all");
  const query = q.trim().toLowerCase();
  const filtered = exercises.filter((e) => {
    if (filter !== "all" && e.status !== filter) return false;
    if (!query) return true;
    return e.name.toLowerCase().includes(query) || e.muscle.toLowerCase().includes(query);
  });

  const chips: { id: "all" | Status; label: string }[] = [
    { id: "all", label: "All" },
    { id: "pr", label: "PR" },
    { id: "progressing", label: "Up" },
    { id: "stalling", label: "Stall" },
    { id: "slipping", label: "Down" },
  ];

  return (
    <section>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="font-display text-2xl tracking-tight">Overload board</h2>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search lifts"
            className="pl-9"
          />
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {chips.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setFilter(c.id)}
            className={cn(
              "h-11 rounded-full px-4 text-sm font-medium transition-colors duration-150",
              filter === c.id
                ? "bg-accent text-accent-fg"
                : "bg-surface text-muted shadow-[var(--shadow-border)]",
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      <ul className="mt-4 overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]">
        {filtered.length === 0 ? (
          <li className="px-4 py-8 text-center text-sm text-muted">No lifts match.</li>
        ) : (
          filtered.map((ex) => (
            <li key={ex.slug} className="border-b border-border last:border-b-0">
              <Link
                to="/lift/$slug"
                params={{ slug: ex.slug }}
                className="flex items-center gap-3 px-4 py-4 transition-colors duration-150 hover:bg-surface-2"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-medium">{ex.name}</p>
                    <Badge tone={ex.status}>{STATUS_LABEL[ex.status]}</Badge>
                  </div>
                  <p className="mt-0.5 text-sm text-muted">
                    {ex.muscle} · {formatAgo(ex.lastDate)}
                  </p>
                </div>
                <div className="hidden text-right sm:block">
                  <p className="tabular text-sm">
                    {formatSetLine(
                      ex.next.sets,
                      ex.lastTopSet?.weightKg ?? 0,
                      ex.lastRepsList,
                      unit,
                      ex.isBodyweight,
                    )}
                  </p>
                  <p className="text-xs text-subtle">
                    next {formatRepsList(ex.next.repsList)}
                    {!ex.isBodyweight ? ` @ ${formatWeight(ex.next.weightKg, unit)}` : ""}
                  </p>
                </div>
              </Link>
            </li>
          ))
        )}
      </ul>
    </section>
  );
}
