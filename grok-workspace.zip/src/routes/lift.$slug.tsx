import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { ExerciseView } from "@/components/exercise-view";
import { Hydrate } from "@/components/hydrate";

export const Route = createFileRoute("/lift/$slug")({
  component: LiftPage,
});

function LiftPage() {
  const { slug } = Route.useParams();
  return (
    <AppShell>
      <Hydrate fallback="Loading lift…">
        <ExerciseView slug={slug} />
      </Hydrate>
    </AppShell>
  );
}
