import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Dashboard } from "@/components/dashboard";
import { Hydrate } from "@/components/hydrate";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <AppShell>
      <Hydrate>
        <Dashboard />
      </Hydrate>
    </AppShell>
  );
}
