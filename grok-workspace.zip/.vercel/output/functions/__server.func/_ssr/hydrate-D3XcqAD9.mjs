import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Upload, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger$1, i as DialogDescription$1, l as Slot, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as format, t as formatDistanceToNowStrict } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hydrate-D3XcqAD9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function mulberry32(seed) {
	return () => {
		let t = seed += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function buildSampleSets(now = Date.parse("2026-10-03T12:00:00")) {
	const rand = mulberry32(42);
	const lastMonday = startOfMonday$1(now - 1728e5);
	const weekCount = 12;
	const firstMonday = lastMonday - 66528e5;
	const lifts = [
		{
			name: "Bench Press (Barbell)",
			days: [1, 6],
			weight: 72.5,
			reps: [
				8,
				8,
				7
			]
		},
		{
			name: "Incline Bench Press (Dumbbell)",
			days: [1],
			weight: 28,
			reps: [
				10,
				10,
				9
			]
		},
		{
			name: "Overhead Press (Barbell)",
			days: [1, 6],
			weight: 47.5,
			reps: [
				6,
				6,
				5
			],
			stallFrom: 7
		},
		{
			name: "Lateral Raise (Dumbbell)",
			days: [1, 6],
			weight: 10,
			reps: [
				12,
				12,
				11
			],
			stallFrom: 5
		},
		{
			name: "Triceps Pushdown (Cable)",
			days: [1],
			weight: 22.5,
			reps: [
				12,
				12,
				10
			]
		},
		{
			name: "Chest Fly (Dumbbell)",
			days: [6],
			weight: 14,
			reps: [
				12,
				12,
				12
			]
		},
		{
			name: "Deadlift (Barbell)",
			days: [2],
			weight: 130,
			reps: [
				5,
				5,
				5
			]
		},
		{
			name: "Lat Pulldown (Cable)",
			days: [2, 6],
			weight: 55,
			reps: [
				10,
				10,
				9
			]
		},
		{
			name: "Seated Row (Cable)",
			days: [2],
			weight: 60,
			reps: [
				10,
				8,
				8
			]
		},
		{
			name: "Face Pull (Cable)",
			days: [2, 6],
			weight: 15,
			reps: [
				15,
				15,
				12
			]
		},
		{
			name: "Bicep Curl (Barbell)",
			days: [2],
			weight: 30,
			reps: [
				10,
				10,
				8
			]
		},
		{
			name: "Pull Up",
			days: [6],
			weight: 0,
			reps: [
				8,
				7,
				6
			],
			bodyweight: true
		},
		{
			name: "Squat (Barbell)",
			days: [4],
			weight: 100,
			reps: [
				6,
				6,
				5
			]
		},
		{
			name: "Romanian Deadlift (Barbell)",
			days: [4],
			weight: 90,
			reps: [
				8,
				8,
				8
			]
		},
		{
			name: "Leg Press",
			days: [4],
			weight: 160,
			reps: [
				10,
				10,
				10
			]
		},
		{
			name: "Lying Leg Curl (Machine)",
			days: [4],
			weight: 40,
			reps: [
				12,
				10,
				10
			]
		},
		{
			name: "Calf Raise (Standing)",
			days: [4],
			weight: 80,
			reps: [
				12,
				12,
				12
			]
		},
		{
			name: "Hip Thrust (Barbell)",
			days: [4],
			weight: 80,
			reps: [
				8,
				8,
				8
			]
		}
	];
	const titles = {
		1: "Push",
		2: "Pull",
		4: "Legs",
		6: "Upper"
	};
	const hours = {
		1: [17, 30],
		2: [18, 0],
		4: [17, 0],
		6: [10, 30]
	};
	const sets = [];
	for (let w = 0; w < weekCount; w++) {
		const deload = w === 8;
		const skipUpper = w === 5;
		for (const day of [
			1,
			2,
			4,
			6
		]) {
			if (skipUpper && day === 6) continue;
			const monday = new Date(firstMonday);
			monday.setDate(monday.getDate() + w * 7);
			const [hh, mm] = hours[day];
			const start = new Date(monday);
			start.setDate(start.getDate() + (day - 1));
			start.setHours(hh, mm, 0, 0);
			if (start.getTime() > now) continue;
			const end = new Date(start.getTime() + 432e4);
			const title = titles[day];
			for (const lift of lifts) {
				if (!lift.days.includes(day)) continue;
				const stalled = lift.stallFrom != null && w >= lift.stallFrom;
				if (w > 0 && !stalled && !lift.bodyweight && w !== 8 && w !== 9) {
					const minR = Math.min(...lift.reps);
					const ceiling = lift.reps[0] >= 10 ? 12 : lift.reps[0] >= 8 ? 8 : 6;
					if (lift.reps.every((r) => r >= ceiling)) {
						lift.weight += lift.weight >= 80 ? 5 : 2.5;
						lift.reps = lift.reps.map(() => Math.max(5, ceiling - 2));
					} else if (minR < ceiling && rand() > .25) {
						const i = lift.reps.indexOf(minR);
						lift.reps[i] = minR + 1;
					}
				}
				if (lift.bodyweight && w > 0 && w % 2 === 0 && w < 11) {
					const i = lift.reps.indexOf(Math.min(...lift.reps));
					lift.reps[i] += 1;
				}
				if (stalled && w > (lift.stallFrom ?? 0) && rand() < .4) {
					const i = Math.floor(rand() * lift.reps.length);
					lift.reps[i] = Math.max(4, lift.reps[i] + (rand() > .5 ? 1 : -1));
				}
				if (w === 11 && lift.name === "Bench Press (Barbell)") {
					lift.weight = 90;
					lift.reps = [
						6,
						6,
						5
					];
				}
				if (w === 11 && lift.name === "Deadlift (Barbell)") {
					lift.weight = 150;
					lift.reps = [
						5,
						5,
						4
					];
				}
				if (w === 10 && lift.name === "Incline Bench Press (Dumbbell)") lift.reps = [
					8,
					7,
					6
				];
				const workingW = deload && !lift.bodyweight ? round2p5(lift.weight * .9) : lift.weight;
				const workingReps = deload ? lift.reps.map((r) => Math.max(5, r - 1)) : lift.reps;
				let idx = 0;
				if (!lift.bodyweight) {
					pushSet(sets, title, start, end, lift.name, idx++, "warmup", round2p5(workingW * .5), 8);
					pushSet(sets, title, start, end, lift.name, idx++, "warmup", round2p5(workingW * .75), 5);
				}
				for (const r of workingReps) {
					const jitter = stalled && rand() < .15 ? -1 : 0;
					pushSet(sets, title, start, end, lift.name, idx++, "normal", lift.bodyweight ? 0 : workingW, Math.max(3, r + jitter));
				}
			}
		}
	}
	return sets;
}
function pushSet(sets, title, start, end, exercise, setIndex, setType, weightKg, reps) {
	sets.push({
		workoutTitle: title,
		start: start.getTime(),
		end: end.getTime(),
		exercise,
		setIndex,
		setType,
		weightKg,
		reps,
		durationSec: null,
		distanceM: null,
		rpe: setType === "normal" ? 7.5 : null,
		notes: ""
	});
}
function round2p5(n) {
	return Math.round(n * 2) / 2;
}
function startOfMonday$1(ts) {
	const d = new Date(ts);
	const day = d.getDay();
	const diff = day === 0 ? -6 : 1 - day;
	d.setDate(d.getDate() + diff);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
var useRampStore = create()(persist((set) => ({
	hydrated: false,
	unit: "kg",
	source: "sample",
	sets: buildSampleSets(),
	fileName: null,
	importedAt: null,
	setHydrated: () => set({ hydrated: true }),
	setUnit: (unit) => set({ unit }),
	loadImported: (sets, fileName) => set({
		sets,
		fileName,
		source: "import",
		importedAt: Date.now()
	}),
	loadSample: () => set({
		sets: buildSampleSets(),
		source: "sample",
		fileName: null,
		importedAt: null
	}),
	clear: () => set({
		sets: [],
		source: "empty",
		fileName: null,
		importedAt: null
	})
}), {
	name: "ramp-hevy-v1",
	partialize: (s) => ({
		unit: s.unit,
		source: s.source,
		sets: s.sets,
		fileName: s.fileName,
		importedAt: s.importedAt
	}),
	skipHydration: true
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var tones = {
	pr: "bg-up/15 text-up",
	progressing: "bg-up/15 text-up",
	holding: "bg-fg/8 text-muted",
	stalling: "bg-hold/15 text-hold",
	slipping: "bg-down/15 text-down",
	new: "bg-fg/8 text-muted",
	sample: "bg-accent/15 text-accent",
	muted: "bg-fg/8 text-muted"
};
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-6 items-center rounded-full px-2.5 text-xs font-medium tracking-wide", tones[tone], className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,box-shadow] duration-150 ease-out focus-visible:outline-none disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[var(--shadow-border)] hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "bg-transparent text-fg hover:bg-surface-2",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-md px-5 text-base",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-bg/70 data-[state=open]:animate-in data-[state=closed]:animate-out" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]", "data-[state=open]:animate-in data-[state=closed]:animate-out", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 flex size-11 items-center justify-center rounded-sm text-muted transition-opacity duration-150 hover:text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-xl tracking-tight text-fg", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1 text-sm text-muted", className),
		...props
	});
}
var KG_PER_LB = .45359237;
function kgToDisplay(kg, unit) {
	if (unit === "lb") return kg / KG_PER_LB;
	return kg;
}
function plateIncrementKg(unit) {
	return unit === "lb" ? 5 * KG_PER_LB : 2.5;
}
function niceWeight(kg, unit) {
	const raw = kgToDisplay(kg, unit);
	const step = unit === "lb" ? .5 : .25;
	return Math.round(raw / step) * step;
}
function formatWeight(kg, unit, digits) {
	const v = niceWeight(kg, unit);
	const d = digits ?? (unit === "lb" ? v % 1 === 0 ? 0 : 1 : v % 1 === 0 ? 0 : 2);
	return `${trimNum(Number.isInteger(v) ? v.toFixed(0) : v.toFixed(Math.min(d, 2)))} ${unit}`;
}
function formatIncrement(unit) {
	return unit === "lb" ? "5 lb" : "2.5 kg";
}
function trimNum(n) {
	if (!n.includes(".")) return n;
	return n.replace(/\.?0+$/, "");
}
function toSlug(name) {
	return name.toLowerCase().normalize("NFKD").replace(/[()]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "exercise";
}
function parseWorkoutCsv(text) {
	const rows = parseCsv(text);
	if (rows.length < 2) throw new Error("This file looks empty. Export workouts from Hevy and try again.");
	const idx = indexColumns(rows[0].map(normalizeHeader));
	if (idx.exercise < 0 || idx.start < 0) throw new Error("Couldn't read this CSV. Export from Hevy via Profile → Settings → Export & Import Data → Export Workouts.");
	const format = idx.hevyNative ? "hevy" : "strong";
	const warnings = [];
	const sets = [];
	let skipped = 0;
	let inferredLbs = false;
	const weightIsLbsColumn = idx.weightLbs >= 0 && idx.weightKg < 0;
	let strongWeightLbs = null;
	if (!idx.hevyNative && idx.weight >= 0) {
		const values = [];
		for (let r = 1; r < rows.length; r++) {
			const n = num(rows[r][idx.weight]);
			if (n !== null && n > 0) values.push(n);
		}
		strongWeightLbs = values.reduce((a, b) => Math.max(a, b), 0) > 280;
		if (strongWeightLbs) inferredLbs = true;
	}
	for (let r = 1; r < rows.length; r++) {
		const row = rows[r];
		if (row.every((c) => !c.trim())) continue;
		const exercise = (row[idx.exercise] ?? "").trim();
		const startRaw = (row[idx.start] ?? "").trim();
		if (!exercise || !startRaw) {
			skipped += 1;
			continue;
		}
		const start = parseTime(startRaw);
		if (Number.isNaN(start)) {
			skipped += 1;
			continue;
		}
		let end = idx.end >= 0 ? parseTime(row[idx.end] ?? "") : NaN;
		if (Number.isNaN(end)) end = start;
		let weightKg = null;
		if (idx.weightKg >= 0) weightKg = num(row[idx.weightKg]);
		else if (idx.weightLbs >= 0) {
			const lbs = num(row[idx.weightLbs]);
			weightKg = lbs === null ? null : lbs * KG_PER_LB;
		} else if (idx.weight >= 0) {
			const w = num(row[idx.weight]);
			if (w !== null) weightKg = strongWeightLbs ? w * KG_PER_LB : w;
		}
		const setType = (idx.setType >= 0 ? row[idx.setType] : "normal")?.trim() || "normal";
		sets.push({
			workoutTitle: (idx.title >= 0 ? row[idx.title] : "Workout")?.trim() || "Workout",
			start,
			end,
			exercise,
			setIndex: int(idx.setIndex >= 0 ? row[idx.setIndex] : "") ?? r,
			setType,
			weightKg,
			reps: idx.reps >= 0 ? num(row[idx.reps]) : null,
			durationSec: idx.seconds >= 0 ? num(row[idx.seconds]) : null,
			distanceM: parseDistance(row, idx),
			rpe: idx.rpe >= 0 ? num(row[idx.rpe]) : null,
			notes: (idx.notes >= 0 ? row[idx.notes] : "")?.trim() || ""
		});
	}
	if (sets.length === 0) throw new Error("No workout sets found in that file.");
	if (skipped > 0) warnings.push(`Skipped ${skipped} incomplete row${skipped === 1 ? "" : "s"}.`);
	if (weightIsLbsColumn) warnings.push("Read weights from weight_lbs.");
	if (inferredLbs) warnings.push("Treated the Weight column as pounds (values looked like lbs).");
	return {
		sets,
		warnings,
		format
	};
}
function parseDistance(row, idx) {
	if (idx.distanceKm >= 0) {
		const n = num(row[idx.distanceKm]);
		return n === null ? null : n * 1e3;
	}
	if (idx.distanceMiles >= 0) {
		const n = num(row[idx.distanceMiles]);
		return n === null ? null : n * 1609.344;
	}
	if (idx.distance >= 0) return num(row[idx.distance]);
	return null;
}
function indexColumns(header) {
	const find = (...names) => header.findIndex((h) => names.includes(h));
	const exercise = find("exercise_title", "exercise_name", "exercise");
	const start = find("start_time", "date", "workout_datetime", "start");
	return {
		hevyNative: header.includes("exercise_title") || header.includes("start_time"),
		title: find("title", "workout_name", "workout"),
		start,
		end: find("end_time", "end"),
		exercise,
		setIndex: find("set_index", "set_order", "set"),
		setType: find("set_type"),
		weightKg: find("weight_kg"),
		weightLbs: find("weight_lbs"),
		weight: find("weight"),
		reps: find("reps", "repetitions"),
		seconds: find("duration_seconds", "seconds"),
		rpe: find("rpe"),
		notes: find("exercise_notes", "notes"),
		distanceKm: find("distance_km"),
		distanceMiles: find("distance_miles"),
		distance: find("distance")
	};
}
function normalizeHeader(h) {
	return h.replace(/^\uFEFF/, "").trim().toLowerCase().replace(/[\s-]+/g, "_");
}
function num(raw) {
	if (raw == null) return null;
	const t = raw.trim();
	if (!t) return null;
	const n = Number(t.replace(",", "."));
	return Number.isFinite(n) ? n : null;
}
function int(raw) {
	const n = num(raw);
	return n === null ? null : Math.round(n);
}
var MONTHS = {
	jan: 0,
	feb: 1,
	mar: 2,
	apr: 3,
	may: 4,
	jun: 5,
	jul: 6,
	aug: 7,
	sep: 8,
	oct: 9,
	nov: 10,
	dec: 11
};
function parseTime(raw) {
	const t = raw.trim();
	if (!t) return NaN;
	const iso = Date.parse(t);
	if (!Number.isNaN(iso)) return iso;
	const m = t.match(/^(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})(?:[,T ]\s*(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
	if (m) {
		const month = MONTHS[m[2].slice(0, 3).toLowerCase()];
		if (month !== void 0) return new Date(Number(m[3]), month, Number(m[1]), Number(m[4] ?? 12), Number(m[5] ?? 0), Number(m[6] ?? 0)).getTime();
	}
	const sql = t.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
	if (sql) return new Date(Number(sql[1]), Number(sql[2]) - 1, Number(sql[3]), Number(sql[4]), Number(sql[5]), Number(sql[6] ?? 0)).getTime();
	return NaN;
}
function parseCsv(text) {
	const rows = [];
	let row = [];
	let cur = "";
	let i = 0;
	let inQuotes = false;
	const s = text.replace(/^\uFEFF/, "");
	while (i < s.length) {
		const c = s[i];
		if (inQuotes) {
			if (c === "\"") {
				if (s[i + 1] === "\"") {
					cur += "\"";
					i += 2;
					continue;
				}
				inQuotes = false;
				i += 1;
				continue;
			}
			cur += c;
			i += 1;
			continue;
		}
		if (c === "\"") {
			inQuotes = true;
			i += 1;
			continue;
		}
		if (c === ",") {
			row.push(cur);
			cur = "";
			i += 1;
			continue;
		}
		if (c === "\n" || c === "\r") {
			if (c === "\r" && s[i + 1] === "\n") i += 1;
			row.push(cur);
			cur = "";
			if (row.some((x) => x.length > 0) || rows.length > 0) rows.push(row);
			row = [];
			i += 1;
			continue;
		}
		cur += c;
		i += 1;
	}
	row.push(cur);
	if (row.some((x) => x.length > 0)) rows.push(row);
	return rows;
}
function ImportDialog({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [paste, setPaste] = (0, import_react.useState)("");
	const inputRef = (0, import_react.useRef)(null);
	const loadImported = useRampStore((s) => s.loadImported);
	const loadSample = useRampStore((s) => s.loadSample);
	const clear = useRampStore((s) => s.clear);
	const source = useRampStore((s) => s.source);
	function ingest(text, name) {
		setError(null);
		try {
			const result = parseWorkoutCsv(text);
			loadImported(result.sets, name);
			const workouts = new Set(result.sets.map((s) => `${s.start}|${s.workoutTitle}`)).size;
			toast.success(`Imported ${workouts} workouts · ${result.sets.length} sets`);
			if (result.warnings[0]) toast.message(result.warnings[0]);
			setOpen(false);
			setPaste("");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not read that file.");
		}
	}
	async function onFile(file) {
		ingest(await file.text(), file.name);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Import Hevy export" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "In Hevy: Profile → Settings → Export & Import Data → Export Workouts. Drop the CSV here — nothing leaves this device." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => inputRef.current?.click(),
				onDragOver: (e) => {
					e.preventDefault();
					setDrag(true);
				},
				onDragLeave: () => setDrag(false),
				onDrop: (e) => {
					e.preventDefault();
					setDrag(false);
					const file = e.dataTransfer.files[0];
					if (file) onFile(file);
				},
				className: cn("mt-5 flex min-h-32 w-full flex-col items-center justify-center gap-2 rounded-lg bg-surface-2 px-4 text-center shadow-[var(--shadow-border)] transition-[box-shadow] duration-150", drag && "shadow-[var(--shadow-border-hover)]"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5 text-muted" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-fg",
						children: "Drop CSV or click to choose"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-subtle",
						children: "One row per set · Hevy or Strong format"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: ".csv,text/csv",
				className: "hidden",
				onChange: (e) => {
					const file = e.target.files?.[0];
					if (file) onFile(file);
					e.currentTarget.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-xs font-medium tracking-wide text-muted uppercase",
				children: ["Or paste CSV", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: paste,
					onChange: (e) => setPaste(e.target.value),
					rows: 4,
					className: "mt-2 w-full resize-y rounded-md bg-surface-2 p-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none",
					placeholder: "title,start_time,exercise_title,..."
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-down",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col gap-2 sm:flex-row sm:justify-end",
				children: [
					source !== "empty" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => {
							clear();
							setOpen(false);
							toast.message("Log cleared");
						},
						children: "Clear log"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => {
							loadSample();
							setOpen(false);
							toast.success("Loaded a 12-week sample log");
						},
						children: "Load sample"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						disabled: !paste.trim(),
						onClick: () => ingest(paste, "pasted.csv"),
						children: "Import paste"
					})
				]
			})
		] })]
	});
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: cn("size-6", className),
		fill: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M3 19h4V14H3v5Zm7 0h4V9h-4v10Zm7 0h4V4h-4v15Z",
			fill: "currentColor"
		})
	});
}
function AppShell({ children }) {
	const unit = useRampStore((s) => s.unit);
	const setUnit = useRampStore((s) => s.setUnit);
	const source = useRampStore((s) => s.source);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-14 max-w-5xl items-center justify-between gap-3 px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-5 text-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg tracking-[0.08em]",
							children: "RAMP"
						}),
						source === "sample" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "sample",
							className: "hidden sm:inline-flex",
							children: "Sample"
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-11 rounded-md bg-surface-2 p-1 shadow-[var(--shadow-border)]",
						children: ["kg", "lb"].map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setUnit(u),
							className: cn("min-w-11 rounded-sm px-3 text-sm font-medium transition-colors duration-150", unit === u ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
							children: u
						}, u))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportDialog, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "md",
						children: "Import"
					}) })]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto w-full max-w-5xl px-4 pt-8 pb-[max(2rem,env(safe-area-inset-bottom))]",
			children
		})]
	});
}
var RULES = [
	{
		muscle: "Chest",
		tests: [
			/bench/,
			/chest/,
			/\bfly\b/,
			/pec/,
			/push[-\s]?up/,
			/pullover/
		]
	},
	{
		muscle: "Back",
		tests: [
			/deadlift(?!.*romanian)/,
			/\brow\b/,
			/pulldown/,
			/pull[-\s]?up/,
			/chin[-\s]?up/,
			/lat\b/,
			/shrug/,
			/face\s*pull/,
			/rear\s*delt/
		]
	},
	{
		muscle: "Shoulders",
		tests: [
			/overhead press/,
			/shoulder/,
			/lateral raise/,
			/front raise/,
			/\bohp\b/,
			/arnold/
		]
	},
	{
		muscle: "Legs",
		tests: [
			/squat/,
			/lunge/,
			/leg press/,
			/leg curl/,
			/leg extension/,
			/rdl/,
			/romanian/,
			/hip thrust/,
			/glute/,
			/calf/,
			/hack/,
			/split squat/,
			/step[- ]?up/
		]
	},
	{
		muscle: "Arms",
		tests: [
			/curl/,
			/tricep/,
			/pushdown/,
			/skull/,
			/extension \(cable\)/,
			/\bdip\b/,
			/hammer/
		]
	},
	{
		muscle: "Core",
		tests: [
			/plank/,
			/crunch/,
			/sit-?up/,
			/pallof/,
			/ab\b/,
			/hanging leg/,
			/cable wood/
		]
	}
];
function classifyMuscle(name) {
	const n = name.toLowerCase();
	for (const rule of RULES) if (rule.tests.some((re) => re.test(n))) return rule.muscle;
	return "Other";
}
var DAY = 864e5;
var WEEK = 7 * DAY;
function analyze(sets, unit, now = Date.now()) {
	const working = sets.filter(isWorkingSet);
	const byExercise = /* @__PURE__ */ new Map();
	for (const s of working) {
		const list = byExercise.get(s.exercise);
		if (list) list.push(s);
		else byExercise.set(s.exercise, [s]);
	}
	const exercises = [];
	const slugUsed = /* @__PURE__ */ new Set();
	for (const [name, rows] of byExercise) {
		const sessions = groupSessions(rows);
		if (sessions.length === 0) continue;
		const isBodyweight = sessions.every((s) => s.workingWeightKg <= 0);
		const last = sessions[sessions.length - 1];
		const prev = sessions.length > 1 ? sessions[sessions.length - 2] : null;
		const bestE1rm = sessions.reduce((m, s) => Math.max(m, s.e1rm), 0);
		const status = classifyStatus(sessions, now);
		const stallSessions = countStall(sessions);
		const next = prescribe(sessions, unit, stallSessions, isBodyweight);
		let slug = toSlug(name);
		if (slugUsed.has(slug)) slug = `${slug}-${sessions.length}`;
		slugUsed.add(slug);
		const lastMetric = metric(last);
		const prevMetric = prev ? metric(prev) : lastMetric;
		exercises.push({
			name,
			slug,
			muscle: classifyMuscle(name),
			lastDate: last.start,
			sessions: sessions.length,
			lastTopSet: last.topSets[0] ?? null,
			lastRepsList: last.topSets.map((t) => t.reps),
			lastVolume: last.volumeKg,
			bestE1rm,
			lastE1rm: last.e1rm,
			e1rmDelta: prev ? lastMetric - prevMetric : 0,
			volumeDelta: prev ? last.volumeKg - prev.volumeKg : 0,
			status,
			stallSessions,
			next,
			trend: sessions.map((s) => ({
				date: s.start,
				e1rm: s.e1rm,
				volume: s.volumeKg,
				topWeight: s.workingWeightKg
			})),
			history: sessions,
			isBodyweight
		});
	}
	exercises.sort((a, b) => statusRank(a.status) - statusRank(b.status) || b.lastDate - a.lastDate);
	const weeklyVolume = weeklyBuckets(working, now);
	const due = pickDue(exercises, working, now);
	const weekAgo = now - 7 * DAY;
	const twoWeeks = now - 14 * DAY;
	const monthAgo = now - 28 * DAY;
	const workoutKeys = /* @__PURE__ */ new Set();
	for (const s of working) if (s.start >= monthAgo) workoutKeys.add(`${s.start}|${s.workoutTitle}`);
	return {
		exercises,
		weeklyVolume,
		due,
		lastWorkoutTitle: latestTitle(working),
		lastWorkoutDate: working.reduce((m, s) => Math.max(m, s.start), 0) || null,
		stats: {
			sessions28: workoutKeys.size,
			volume7: volumeBetween(working, weekAgo, now),
			volume7prev: volumeBetween(working, twoWeeks, weekAgo),
			prs28: exercises.filter((e) => e.status === "pr" && e.lastDate >= monthAgo).length,
			stalled: exercises.filter((e) => e.status === "stalling").length,
			lifts: exercises.length
		}
	};
}
function isWorkingSet(s) {
	const t = s.setType.toLowerCase().replace(/[\s_-]+/g, "");
	if (t.includes("warm") || t.includes("cool")) return false;
	const hasReps = (s.reps ?? 0) > 0;
	const hasWeight = (s.weightKg ?? 0) > 0;
	if ((s.durationSec ?? 0) > 0 && !hasReps) return false;
	return hasReps || hasWeight;
}
function groupSessions(rows) {
	const map = /* @__PURE__ */ new Map();
	for (const s of rows) {
		const key = `${s.start}|${s.workoutTitle}`;
		const list = map.get(key);
		if (list) list.push(s);
		else map.set(key, [s]);
	}
	const sessions = [];
	for (const [, group] of map) {
		const session = toSession(group);
		if (session) sessions.push(session);
	}
	sessions.sort((a, b) => a.start - b.start);
	return sessions;
}
function toSession(group) {
	const usable = group.filter((s) => (s.reps ?? 0) > 0);
	if (usable.length === 0) return null;
	const weights = usable.map((s) => s.weightKg ?? 0);
	const workingWeightKg = Math.max(...weights);
	const band = workingWeightKg > 0 ? workingWeightKg * .025 : 0;
	const topSets = (workingWeightKg > 0 ? usable.filter((s) => (s.weightKg ?? 0) >= workingWeightKg - band) : usable).map((s) => ({
		weightKg: s.weightKg ?? 0,
		reps: s.reps ?? 0,
		rpe: s.rpe
	}));
	const volumeKg = usable.reduce((sum, s) => sum + (s.weightKg ?? 0) * (s.reps ?? 0), 0);
	const totalReps = usable.reduce((sum, s) => sum + (s.reps ?? 0), 0);
	let e1rm = 0;
	for (const t of topSets) if (t.weightKg > 0 && t.reps > 0) e1rm = Math.max(e1rm, epley(t.weightKg, t.reps));
	const first = group[0];
	return {
		start: first.start,
		workoutTitle: first.workoutTitle,
		topSets,
		workingWeightKg,
		totalReps,
		volumeKg,
		e1rm,
		setCount: topSets.length || usable.length
	};
}
function epley(weight, reps) {
	if (weight <= 0 || reps <= 0) return 0;
	if (reps === 1) return weight;
	return weight * (1 + reps / 30);
}
function metric(s) {
	return s.e1rm > 0 ? s.e1rm : s.totalReps;
}
function classifyStatus(sessions, now) {
	if (sessions.length < 2) return "new";
	const last = sessions[sessions.length - 1];
	const prev = sessions[sessions.length - 2];
	const bestBefore = sessions.slice(0, -1).reduce((m, s) => Math.max(m, metric(s)), 0);
	const lastM = metric(last);
	const prevM = metric(prev);
	if (bestBefore > 0 && lastM >= bestBefore * 1.005 && last.start >= now - 28 * DAY) return "pr";
	if (prevM > 0 && lastM > prevM * 1.012) return "progressing";
	const recent = sessions.slice(-3);
	if (recent.length === 3) {
		const ms = recent.map(metric);
		const max = Math.max(...ms);
		const min = Math.min(...ms);
		if (max > 0 && (max - min) / max < .02) return "stalling";
	}
	if (prevM > 0 && lastM < prevM * .97) return "slipping";
	if (prevM > 0 && lastM > prevM) return "progressing";
	return "holding";
}
function countStall(sessions) {
	if (sessions.length < 2) return 0;
	let n = 1;
	const last = metric(sessions[sessions.length - 1]);
	for (let i = sessions.length - 2; i >= 0; i--) {
		const m = metric(sessions[i]);
		const top = Math.max(m, last);
		if (top > 0 && Math.abs(m - last) / top < .02) n += 1;
		else break;
	}
	return n >= 3 ? n : 0;
}
function inferCeiling(sessions) {
	const reps = sessions.slice(-6).flatMap((s) => s.topSets.map((t) => t.reps));
	if (reps.length === 0) return 8;
	const sorted = [...reps].sort((a, b) => a - b);
	const p80 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * .8))];
	return clamp(p80, 5, 15);
}
function prescribe(sessions, unit, stallSessions, isBodyweight) {
	const last = sessions[sessions.length - 1];
	const ceiling = inferCeiling(sessions);
	const floor = Math.max(1, ceiling - 4);
	const repsList = last.topSets.map((t) => t.reps);
	const minR = repsList.length ? Math.min(...repsList) : 8;
	const sets = last.setCount || 3;
	const inc = plateIncrementKg(unit);
	if (isBodyweight) {
		const nextReps = minR + 1;
		return {
			sets,
			weightKg: 0,
			reps: nextReps,
			repsList: last.topSets.map(() => nextReps),
			kind: "add-reps",
			rationale: `Add 1 rep per set (${minR} → ${nextReps}).`
		};
	}
	if (stallSessions >= 4) return {
		sets,
		weightKg: last.workingWeightKg * .9,
		reps: floor,
		repsList: Array.from({ length: sets }, () => floor),
		kind: "deload",
		rationale: `Flat for ${stallSessions} sessions — reset ~10% and rebuild.`
	};
	if (repsList.length > 0 && repsList.every((r) => r >= ceiling)) return {
		sets,
		weightKg: last.workingWeightKg + inc,
		reps: floor,
		repsList: Array.from({ length: sets }, () => floor),
		kind: "add-weight",
		rationale: `Hit ${ceiling}s across the board — add ${formatIncrement(unit)}.`
	};
	const nextRepsList = last.topSets.map((t) => t.reps < ceiling ? t.reps + 1 : t.reps);
	const lowest = Math.min(...nextRepsList);
	return {
		sets,
		weightKg: last.workingWeightKg,
		reps: lowest,
		repsList: nextRepsList,
		kind: "add-reps",
		rationale: lowest >= ceiling ? `One more clean set of ${ceiling} earns the next jump.` : `Same load. Add 1 rep to the weakest set.`
	};
}
function pickDue(exercises, sets, now) {
	const cutoff = now - 28 * DAY;
	const lastByTitle = /* @__PURE__ */ new Map();
	for (const s of sets) {
		if (s.start < cutoff) continue;
		const prev = lastByTitle.get(s.workoutTitle) ?? 0;
		if (s.start > prev) lastByTitle.set(s.workoutTitle, s.start);
	}
	if (lastByTitle.size === 0) {
		const all = /* @__PURE__ */ new Map();
		for (const s of sets) {
			const prev = all.get(s.workoutTitle) ?? 0;
			if (s.start > prev) all.set(s.workoutTitle, s.start);
		}
		for (const [k, v] of all) lastByTitle.set(k, v);
	}
	if (lastByTitle.size === 0) return null;
	let title = "";
	let lastDate = Number.POSITIVE_INFINITY;
	for (const [t, d] of lastByTitle) if (d < lastDate) {
		lastDate = d;
		title = t;
	}
	const dueExercises = exercises.filter((e) => e.history.some((h) => h.workoutTitle === title)).sort((a, b) => {
		const aLast = lastOnTitle(a, title);
		return lastOnTitle(b, title) - aLast;
	}).slice(0, 8);
	return {
		title,
		lastDate,
		daysSince: Math.max(0, Math.floor((now - lastDate) / DAY)),
		exercises: dueExercises
	};
}
function lastOnTitle(ex, title) {
	for (let i = ex.history.length - 1; i >= 0; i--) if (ex.history[i].workoutTitle === title) return ex.history[i].start;
	return 0;
}
function weeklyBuckets(sets, now) {
	const startMonday = startOfMonday(now - 11 * WEEK);
	const buckets = [];
	const keys = /* @__PURE__ */ new Map();
	for (let i = 0; i < 12; i++) {
		const weekStart = startMonday + i * WEEK;
		buckets.push({
			weekStart,
			volume: 0,
			sessions: 0
		});
		keys.set(weekStart, /* @__PURE__ */ new Set());
	}
	for (const s of sets) {
		const w = startOfMonday(s.start);
		const b = buckets.find((x) => x.weekStart === w);
		if (!b) continue;
		b.volume += (s.weightKg ?? 0) * (s.reps ?? 0);
		keys.get(w)?.add(`${s.start}|${s.workoutTitle}`);
	}
	for (const b of buckets) b.sessions = keys.get(b.weekStart)?.size ?? 0;
	return buckets;
}
function startOfMonday(ts) {
	const d = new Date(ts);
	const day = d.getDay();
	const diff = day === 0 ? -6 : 1 - day;
	d.setDate(d.getDate() + diff);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
function volumeBetween(sets, from, to) {
	let v = 0;
	for (const s of sets) if (s.start >= from && s.start < to) v += (s.weightKg ?? 0) * (s.reps ?? 0);
	return v;
}
function latestTitle(sets) {
	let t = null;
	let m = 0;
	for (const s of sets) if (s.start >= m) {
		m = s.start;
		t = s.workoutTitle;
	}
	return t;
}
function statusRank(s) {
	switch (s) {
		case "pr": return 0;
		case "progressing": return 1;
		case "slipping": return 2;
		case "stalling": return 3;
		case "holding": return 4;
		default: return 5;
	}
}
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function formatRepsList(reps) {
	if (reps.length === 0) return "—";
	return reps.join(", ");
}
function copySessionPlan(due, formatW) {
	const lines = [`RAMP — ${due.title}`];
	for (const ex of due.exercises) {
		const n = ex.next;
		if (ex.isBodyweight) lines.push(`${ex.name}: ${n.sets} × ${n.repsList.join("/")}`);
		else lines.push(`${ex.name}: ${n.sets} × ${formatW(n.weightKg)} × ${n.repsList.join("/")}`);
	}
	return lines.join("\n");
}
var STATUS_LABEL = {
	pr: "PR",
	progressing: "Up",
	holding: "Hold",
	stalling: "Stall",
	slipping: "Down",
	new: "New"
};
function formatDay(ts) {
	return format(ts, "d MMM");
}
function formatAgo(ts, now = Date.now()) {
	if (now - ts < 72e6) return "today";
	if (now - ts < 1296e5) return "yesterday";
	return formatDistanceToNowStrict(ts, { addSuffix: true });
}
function formatSetLine(sets, weightKg, reps, unit, bodyweight) {
	const repsBit = reps.length ? reps.join(", ") : "—";
	if (bodyweight || weightKg <= 0) return `${sets} × ${repsBit}`;
	return `${sets} × ${formatWeight(weightKg, unit)} × ${repsBit}`;
}
function formatVolume(kg, unit) {
	const v = unit === "lb" ? kg / .45359237 : kg;
	if (v >= 1e4) return `${(v / 1e3).toFixed(1)}k ${unit}`;
	if (v >= 1e3) return `${Math.round(v).toLocaleString()} ${unit}`;
	return `${Math.round(v)} ${unit}`;
}
function pctDelta(curr, prev) {
	if (!prev) return null;
	return (curr - prev) / prev * 100;
}
function Hydrate({ children, fallback = "Loading your training log…" }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const finish = () => {
			if (cancelled) return;
			useRampStore.getState().setHydrated();
			setReady(true);
		};
		if (useRampStore.persist.hasHydrated()) {
			finish();
			return;
		}
		Promise.resolve(useRampStore.persist.rehydrate()).then(finish);
		return () => {
			cancelled = true;
		};
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-display text-4xl tracking-tight",
		children: "RAMP"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-muted",
		children: fallback
	})] });
	return children;
}
//#endregion
export { useRampStore as _, ImportDialog as a, cn as c, formatDay as d, formatRepsList as f, pctDelta as g, formatWeight as h, Hydrate as i, copySessionPlan as l, formatVolume as m, Badge as n, STATUS_LABEL as o, formatSetLine as p, Button as r, analyze as s, AppShell as t, formatAgo as u };
