import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Copy, i as Search } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as useRampStore, a as ImportDialog, c as cn, d as formatDay, f as formatRepsList, g as pctDelta, h as formatWeight, i as Hydrate, l as copySessionPlan, m as formatVolume, n as Badge, o as STATUS_LABEL, p as formatSetLine, r as Button, s as analyze, t as AppShell, u as formatAgo } from "./hydrate-D3XcqAD9.mjs";
import { i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dr_-EY3P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-surface-2 px-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:outline-none", className),
		...props
	});
}
function Dashboard() {
	const sets = useRampStore((s) => s.sets);
	const unit = useRampStore((s) => s.unit);
	const source = useRampStore((s) => s.source);
	const model = (0, import_react.useMemo)(() => analyze(sets, unit), [sets, unit]);
	if (sets.length === 0 || source === "empty") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [
			source === "sample" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Showing a 12-week sample log. Import your Hevy CSV to replace it — analysis stays on this device."
			}) : null,
			model.due ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DueCard, {
				due: model.due,
				unit
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsRow, {
				model,
				unit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeChart, {
				model,
				unit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverloadBoard, {
				exercises: model.exercises,
				unit
			})
		]
	});
}
function EmptyState() {
	const loadSample = useRampStore((s) => s.loadSample);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl tracking-tight",
				children: "Bring a Hevy log."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Export workouts from Hevy, drop the CSV here, and RAMP will mark what is moving, what is stuck, and what to run next session."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportDialog, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					children: "Import CSV"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "secondary",
					onClick: () => {
						loadSample();
						toast.success("Loaded a 12-week sample log");
					},
					children: "Load sample log"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-10 space-y-2 text-left text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Open Hevy → Profile → Settings" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. Export & Import Data → Export Workouts" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. Drop the CSV onto RAMP" })
				]
			})
		]
	});
}
function DueCard({ due, unit }) {
	const dueLabel = due.daysSince === 0 ? "Due today" : due.daysSince === 1 ? "Due yesterday" : `Due · ${due.daysSince}d`;
	function copy() {
		const text = copySessionPlan(due, (kg) => formatWeight(kg, unit));
		navigator.clipboard.writeText(text).then(() => toast.success("Copied next-session targets"), () => toast.error("Could not copy"));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] text-muted uppercase",
					children: "Next session"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-4xl tracking-tight sm:text-5xl",
					children: due.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [dueLabel, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-subtle",
						children: [" · last ", formatDay(due.lastDate)]
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "secondary",
				onClick: copy,
				className: "shrink-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copy targets"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 divide-y divide-border",
			children: due.exercises.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/lift/$slug",
				params: { slug: ex.slug },
				className: "flex flex-col gap-1 py-4 transition-opacity duration-150 hover:opacity-80 sm:flex-row sm:items-baseline sm:justify-between sm:gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-medium",
						children: ex.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Last",
							" ",
							formatSetLine(ex.next.sets, ex.lastTopSet?.weightKg ?? 0, ex.lastRepsList, unit, ex.isBodyweight)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-accent",
						children: formatSetLine(ex.next.sets, ex.next.weightKg, ex.next.repsList, unit, ex.isBodyweight)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: ex.next.rationale
					})]
				})]
			}) }, ex.name))
		})]
	});
}
function StatsRow({ model, unit }) {
	const volDelta = pctDelta(model.stats.volume7, model.stats.volume7prev);
	const tiles = [
		{
			label: "This week",
			value: formatVolume(model.stats.volume7, unit),
			hint: volDelta == null ? "volume" : `${volDelta >= 0 ? "+" : ""}${volDelta.toFixed(0)}% vs last week`
		},
		{
			label: "28 days",
			value: String(model.stats.sessions28),
			hint: "sessions"
		},
		{
			label: "PRs",
			value: String(model.stats.prs28),
			hint: "this month"
		},
		{
			label: "Stalled",
			value: String(model.stats.stalled),
			hint: "lifts to watch"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
		children: tiles.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-lg bg-surface px-4 py-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.14em] text-muted uppercase",
					children: t.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-3xl tracking-tight tabular",
					children: t.value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-subtle",
					children: t.hint
				})
			]
		}, t.label))
	});
}
function VolumeChart({ model, unit }) {
	const data = model.weeklyVolume.map((w) => ({
		label: formatDay(w.weekStart),
		volume: unit === "lb" ? w.volume / .45359237 : w.volume,
		sessions: w.sessions
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: "Weekly volume"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Working sets only"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 h-48",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				minWidth: 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
					data,
					margin: {
						top: 8,
						right: 8,
						left: 0,
						bottom: 0
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
							dataKey: "label",
							tick: {
								fill: "var(--color-muted)",
								fontSize: 11
							},
							axisLine: false,
							tickLine: false,
							minTickGap: 28
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							contentStyle: {
								background: "var(--color-surface)",
								border: "1px solid var(--color-border)",
								borderRadius: 8,
								color: "var(--color-fg)"
							},
							formatter: (value) => [`${Math.round(Number(value)).toLocaleString()} ${unit}`, "Volume"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							type: "monotone",
							dataKey: "volume",
							stroke: "var(--color-accent)",
							fill: "var(--color-accent)",
							fillOpacity: .08,
							strokeWidth: 1.5
						})
					]
				})
			})
		})]
	});
}
function OverloadBoard({ exercises, unit }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const query = q.trim().toLowerCase();
	const filtered = exercises.filter((e) => {
		if (filter !== "all" && e.status !== filter) return false;
		if (!query) return true;
		return e.name.toLowerCase().includes(query) || e.muscle.toLowerCase().includes(query);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-tight",
				children: "Overload board"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full sm:w-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search lifts",
					className: "pl-9"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [
				{
					id: "all",
					label: "All"
				},
				{
					id: "pr",
					label: "PR"
				},
				{
					id: "progressing",
					label: "Up"
				},
				{
					id: "stalling",
					label: "Stall"
				},
				{
					id: "slipping",
					label: "Down"
				}
			].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(c.id),
				className: cn("h-11 rounded-full px-4 text-sm font-medium transition-colors duration-150", filter === c.id ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]"),
				children: c.label
			}, c.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)]",
			children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "px-4 py-8 text-center text-sm text-muted",
				children: "No lifts match."
			}) : filtered.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "border-b border-border last:border-b-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/lift/$slug",
					params: { slug: ex.slug },
					className: "flex items-center gap-3 px-4 py-4 transition-colors duration-150 hover:bg-surface-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: ex.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: ex.status,
								children: STATUS_LABEL[ex.status]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-sm text-muted",
							children: [
								ex.muscle,
								" · ",
								formatAgo(ex.lastDate)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden text-right sm:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular text-sm",
							children: formatSetLine(ex.next.sets, ex.lastTopSet?.weightKg ?? 0, ex.lastRepsList, unit, ex.isBodyweight)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-subtle",
							children: [
								"next ",
								formatRepsList(ex.next.repsList),
								!ex.isBodyweight ? ` @ ${formatWeight(ex.next.weightKg, unit)}` : ""
							]
						})]
					})]
				})
			}, ex.slug))
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hydrate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {}) }) });
}
//#endregion
export { Home as component };
