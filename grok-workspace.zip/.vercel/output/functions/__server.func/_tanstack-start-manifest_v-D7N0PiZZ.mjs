//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D7N0PiZZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/lift/$slug"],
		preloads: ["/assets/index-BqPI26ee.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BqPI26ee.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BH_adDeU.js", "/assets/hydrate-CkwJLFfj.js"]
	},
	"/lift/$slug": {
		filePath: "/workspace/src/routes/lift.$slug.tsx",
		children: void 0,
		preloads: ["/assets/lift._slug-BeDRoOLh.js", "/assets/hydrate-CkwJLFfj.js"]
	}
} });
//#endregion
export { tsrStartManifest };
